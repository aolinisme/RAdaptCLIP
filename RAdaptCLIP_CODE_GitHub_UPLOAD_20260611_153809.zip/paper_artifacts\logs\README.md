# Trace Logs

This folder contains selected trace logs used by the IJSAEM manuscript.

The straw risk-fusion table is based on:

- `rtx3070_xiguan_risk_fast_summary.json`
- `rtx3070_xiguan_risk_fast/baseline_sigma4/`
- `rtx3070_xiguan_risk_fast/fixed_gate0p2_sigma4/`
- `rtx3070_xiguan_risk_fast/risk_gate_balanced_sigma4/`
- `rtx3070_xiguan_risk_fast/risk_gate_recall_sigma4/`

The visualization-only capped runs are based on:

- `straw_case_visuals_baseline_20260611/`
- `straw_case_visuals_fixed035_20260611/`
- `straw_case_visuals_riskbalanced_20260611/`

Visualization-only runs use `--max_test_samples 3` and should not be interpreted as full quantitative evidence.
