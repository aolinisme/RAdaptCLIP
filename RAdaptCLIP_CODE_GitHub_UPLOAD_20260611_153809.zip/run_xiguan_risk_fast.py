#!/usr/bin/env python3
"""Fast xiguan 0-shot ablation for risk-calibrated pseudo-pixel fusion.

This runner is intentionally small for an RTX 3070 8 GB GPU. It only evaluates
the xiguan YOLO-converted dataset and writes a compact summary JSON so the paper
table can be traced back to logs.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path


PYTHON = Path(r"D:/work/anaconda/envs/py39_pytorch2.3.1/python.exe")
REPO = Path(r"E:/CILP/AdaptCLIP")
CKPT_VISA = "./adaptclip_checkpoints/12_4_128_train_on_visa_3adapters_batch8/epoch_15.pth"


COMMON_ARGS = [
    "test.py",
    "--test_data_path",
    "./dataset/xiguan_yolo",
    "--dataset",
    "xiguan_yolo",
    "--checkpoint_path",
    CKPT_VISA,
    "--class_name",
    "xiguan",
    "--k_shots",
    "0",
    "--batch_size",
    "4",
    "--num_workers",
    "0",
    "--image_size",
    "518",
    "--features_list",
    "6",
    "12",
    "18",
    "24",
    "--n_ctx",
    "12",
    "--sigma",
    "4",
    "--visual_learner",
    "--textual_learner",
    "--pq_learner",
    "--pq_context",
    "--eval_metrics",
    "P-AUROC",
    "P-AP",
    "P-F1max",
]


RADAPT_PIXEL_ARGS = [
    "--radaptclip",
    "--structure_align",
    "soft_topk",
    "--pseudo_structure_align",
    "prototype",
    "--align_topk",
    "5",
    "--use_pseudo_prompt",
    "--use_pseudo_pixel",
    "--use_uncertainty_fusion",
    "--use_pixel_gate",
    "--no-use_zero_rank_gate",
]


METRIC_RE = re.compile(
    r"^\|\s*xiguan\s*\|\s*(?P<p_auroc>[-+]?\d+(?:\.\d+)?)\s*\|\s*"
    r"(?P<p_ap>[-+]?\d+(?:\.\d+)?)\s*\|\s*(?P<p_f1>[-+]?\d+(?:\.\d+)?)\s*\|",
    re.MULTILINE,
)


@dataclass
class RunResult:
    name: str
    elapsed_sec: float
    returncode: int
    metrics: dict[str, float]
    save_dir: str
    command: list[str]

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and bool(self.metrics)


def run_command(cmd: list[str], timeout: int) -> tuple[int, str, str, float]:
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    env["PYTHONIOENCODING"] = "utf-8"
    start = time.time()
    try:
        proc = subprocess.run(
            cmd,
            cwd=REPO,
            env=env,
            text=True,
            encoding="utf-8",
            errors="replace",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
        )
        return proc.returncode, proc.stdout, proc.stderr, time.time() - start
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout if isinstance(exc.stdout, str) else ""
        stderr = exc.stderr if isinstance(exc.stderr, str) else ""
        return 124, stdout, stderr + f"\nTIMEOUT after {timeout}s", time.time() - start


def parse_metrics(text: str) -> dict[str, float]:
    match = METRIC_RE.search(text)
    if not match:
        return {}
    return {
        "P-AUROC": float(match.group("p_auroc")),
        "P-AP": float(match.group("p_ap")),
        "P-F1max": float(match.group("p_f1")),
    }


def run_experiment(name: str, extra_args: list[str], output_root: Path, timeout: int) -> RunResult:
    save_dir = output_root / name
    save_dir.mkdir(parents=True, exist_ok=True)
    cmd = [str(PYTHON), *COMMON_ARGS, "--save_path", str(save_dir), *extra_args]
    print(f"\n[run] {name}")
    print(" ".join(cmd))
    returncode, stdout, stderr, elapsed = run_command(cmd, timeout)
    (save_dir / "runner_stdout.log").write_text(stdout, encoding="utf-8", errors="replace")
    (save_dir / "runner_stderr.log").write_text(stderr, encoding="utf-8", errors="replace")

    metrics = parse_metrics(stdout + "\n" + stderr)
    if not metrics:
        for log_file in save_dir.glob("*_test_log.txt"):
            metrics = parse_metrics(log_file.read_text(encoding="utf-8", errors="replace"))
            if metrics:
                break

    result = RunResult(
        name=name,
        elapsed_sec=elapsed,
        returncode=returncode,
        metrics=metrics,
        save_dir=str(save_dir),
        command=cmd,
    )
    print(f"[done] {name} ok={result.ok} elapsed={elapsed:.1f}s metrics={metrics}")
    return result


def check_code(timeout: int) -> bool:
    compile_cmd = [
        str(PYTHON),
        "-m",
        "py_compile",
        "test.py",
        "adaptcliplib/adaptclip.py",
        "adaptcliplib/radapt_innovations.py",
    ]
    returncode, stdout, stderr, _ = run_command(compile_cmd, timeout)
    if stdout:
        print(stdout)
    if stderr:
        print(stderr, file=sys.stderr)
    if returncode != 0:
        return False

    help_cmd = [str(PYTHON), "test.py", "--help"]
    returncode, stdout, stderr, _ = run_command(help_cmd, timeout)
    if returncode != 0:
        print(stderr, file=sys.stderr)
        return False
    required = ["--use_risk_calibrated_pseudo_pixel", "--risk_gate_max_weight", "--save_risk_gates"]
    missing = [item for item in required if item not in stdout]
    if missing:
        print(f"missing CLI args: {missing}", file=sys.stderr)
        return False
    return True


def print_summary(results: list[RunResult]) -> None:
    print("\n[summary]")
    print(f"{'name':<34} {'ok':<5} {'sec':>7} {'P-AUROC':>8} {'P-AP':>8} {'P-F1':>8}")
    print("-" * 76)
    for result in results:
        metrics = result.metrics
        print(
            f"{result.name:<34} {str(result.ok):<5} {result.elapsed_sec:7.1f} "
            f"{metrics.get('P-AUROC', '')!s:>8} {metrics.get('P-AP', '')!s:>8} "
            f"{metrics.get('P-F1max', '')!s:>8}"
        )


def main() -> int:
    parser = argparse.ArgumentParser(description="Fast xiguan risk-gate ablation")
    parser.add_argument("--timeout", type=int, default=600)
    parser.add_argument("--output_root", type=Path, default=REPO / "results" / "rtx3070_xiguan_risk_fast")
    parser.add_argument("--skip_checks", action="store_true")
    args = parser.parse_args()

    if not PYTHON.exists():
        print(f"missing interpreter: {PYTHON}", file=sys.stderr)
        return 2
    if not REPO.exists():
        print(f"missing repo: {REPO}", file=sys.stderr)
        return 2
    args.output_root.mkdir(parents=True, exist_ok=True)

    if not args.skip_checks and not check_code(args.timeout):
        print("checks failed; stop before experiments", file=sys.stderr)
        return 1

    experiments = [
        ("baseline_sigma4", []),
        (
            "fixed_gate0p2_sigma4",
            [
                *RADAPT_PIXEL_ARGS,
                "--pixel_gate_max_weight",
                "0.2",
            ],
        ),
        (
            "risk_gate_balanced_sigma4",
            [
                *RADAPT_PIXEL_ARGS,
                "--use_risk_calibrated_pseudo_pixel",
                "--risk_gate_base_weight",
                "0.05",
                "--risk_gate_max_weight",
                "0.35",
                "--risk_gate_area_target",
                "0.25",
                "--save_risk_gates",
            ],
        ),
        (
            "risk_gate_recall_sigma4",
            [
                *RADAPT_PIXEL_ARGS,
                "--use_risk_calibrated_pseudo_pixel",
                "--risk_gate_base_weight",
                "0.1",
                "--risk_gate_max_weight",
                "0.5",
                "--risk_gate_area_target",
                "0.35",
                "--save_risk_gates",
            ],
        ),
    ]

    results = [run_experiment(name, extra, args.output_root, args.timeout) for name, extra in experiments]
    print_summary(results)
    summary = {
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "results": [asdict(result) for result in results],
    }
    summary_file = args.output_root / "summary.json"
    summary_file.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\nsummary saved: {summary_file}")
    return 0 if all(result.ok for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
