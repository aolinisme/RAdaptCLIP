#!/usr/bin/env python3
"""Low-risk R-AdaptCLIP experiment runner for an RTX 3070 8 GB GPU.

The runner intentionally starts small:
1. code checks,
2. VisA/candle 0-shot smoke test,
3. optional VisA three-class 0-shot comparison.

It avoids the long multi-shot/multi-seed shell script and retries with a smaller
batch size when CUDA OOM is detected.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable


PYTHON = Path(r"D:/work/anaconda/envs/py39_pytorch2.3.1/python.exe")
REPO = Path(r"E:/CILP/AdaptCLIP")
CKPT_MVTEC = "./adaptclip_checkpoints/12_4_128_train_on_mvtec_3adapters_batch8/epoch_15.pth"
DEFAULT_TIMEOUT = 600
DEFAULT_BATCH = 4
FALLBACK_BATCH = 2

BASE_ARGS = [
    "--dataset",
    "visa",
    "--test_data_path",
    "./dataset/visa",
    "--seed",
    "10",
    "--features_list",
    "6",
    "12",
    "18",
    "24",
    "--image_size",
    "518",
    "--n_ctx",
    "12",
    "--vl_reduction",
    "4",
    "--pq_mid_dim",
    "128",
    "--visual_learner",
    "--textual_learner",
    "--pq_learner",
    "--pq_context",
    "--sigma",
    "4",
    "--fusion_type",
    "average_mean",
    "--eval_metrics",
    "I-AUROC",
    "I-AP",
    "I-F1max",
    "P-AUROC",
    "P-AP",
    "P-F1max",
    "--k_shots",
    "0",
    "--checkpoint_path",
    CKPT_MVTEC,
]

RADAPT_ARGS = [
    "--radaptclip",
    "--structure_align",
    "soft_topk",
    "--align_topk",
    "5",
    "--use_pseudo_prompt",
    "--use_uncertainty_fusion",
    "--use_pixel_gate",
    "--pixel_gate_max_weight",
    "0.1",
    "--pseudo_structure_align",
    "prototype",
    "--image_gate_max_weight",
    "0.1",
    "--use_zero_rank_gate",
    "--zero_rank_gate_max_weight",
    "0.5",
    "--zero_rank_gate_min_corr",
    "0.0",
]

METRIC_COLUMNS = [
    "Name",
    "I-AUROC",
    "I-AP",
    "I-F1max",
    "P-AUROC",
    "P-AP",
    "P-F1max",
    "P-AUPRO",
]


@dataclass
class RunResult:
    name: str
    class_name: str
    method: str
    batch_size: int
    elapsed_sec: float
    returncode: int
    timed_out: bool
    metrics: dict[str, float | str]
    save_dir: str
    command: list[str]

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and bool(self.metrics) and not self.timed_out


def run_command(
    cmd: list[str],
    timeout: int,
    env_extra: dict[str, str] | None = None,
) -> tuple[int, str, str, float, bool]:
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"
    env["PYTHONIOENCODING"] = "utf-8"
    if env_extra:
        env.update(env_extra)

    start = time.time()
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(REPO),
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        return proc.returncode, proc.stdout, proc.stderr, time.time() - start, False
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode("utf-8", errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode("utf-8", errors="replace")
        return 124, stdout, stderr, time.time() - start, True


def parse_metric_table(text: str, class_name: str) -> dict[str, float | str]:
    rows: list[dict[str, float | str]] = []
    header: list[str] | None = None

    for raw in text.splitlines():
        line = raw.strip()
        if not (line.startswith("|") and line.endswith("|")):
            continue
        parts = [part.strip() for part in line.strip("|").split("|")]
        if not parts:
            continue
        if all(part and set(part) <= set(":- ") for part in parts):
            continue
        if "Name" in parts:
            header = parts
            continue
        if header and len(parts) == len(header):
            row: dict[str, float | str] = {}
            for key, value in zip(header, parts):
                try:
                    row[key] = float(value)
                except ValueError:
                    row[key] = value
            rows.append(row)

    for row in reversed(rows):
        if str(row.get("Name")) == class_name:
            return row
    return rows[-1] if rows else {}


def has_cuda_oom(stdout: str, stderr: str) -> bool:
    text = f"{stdout}\n{stderr}".lower()
    return "cuda out of memory" in text or "outofmemoryerror" in text


def print_tail(text: str, n: int = 20) -> None:
    lines = [line for line in text.splitlines() if line.strip()]
    for line in lines[-n:]:
        print("    " + line[:220])


def check_code(timeout: int) -> bool:
    print("\n[checks] py_compile")
    py_files = [
        "test.py",
        "train.py",
        "adaptcliplib/adaptclip.py",
        "adaptcliplib/radapt_innovations.py",
    ]
    cmd = [str(PYTHON), "-m", "py_compile", *py_files]
    rc, out, err, elapsed, timed_out = run_command(cmd, timeout)
    print(f"  returncode={rc} elapsed={elapsed:.1f}s")
    if out.strip():
        print_tail(out, 8)
    if err.strip():
        print_tail(err, 12)
    if rc != 0 or timed_out:
        return False

    print("\n[checks] test.py --help")
    rc, out, err, elapsed, timed_out = run_command([str(PYTHON), "test.py", "--help"], timeout)
    required = ["--radaptclip", "--structure_align", "--use_pseudo_prompt", "--use_uncertainty_fusion", "--use_pixel_gate"]
    missing = [token for token in required if token not in out]
    print(f"  returncode={rc} elapsed={elapsed:.1f}s missing={missing}")
    if err.strip():
        print_tail(err, 12)
    return rc == 0 and not timed_out and not missing


def build_test_command(
    class_name: str,
    method: str,
    batch_size: int,
    save_dir: Path,
    max_test_samples: int = 0,
) -> list[str]:
    cmd = [
        str(PYTHON),
        "test.py",
        *BASE_ARGS,
        "--batch_size",
        str(batch_size),
        "--num_workers",
        "0",
        "--class_name",
        class_name,
        "--save_path",
        str(save_dir),
    ]
    if max_test_samples > 0:
        cmd.extend(["--max_test_samples", str(max_test_samples)])
    if method == "radapt":
        cmd.extend(RADAPT_ARGS)
    return cmd


def run_experiment(
    name: str,
    class_name: str,
    method: str,
    output_root: Path,
    timeout: int,
    first_batch: int,
    fallback_batch: int,
    max_test_samples: int = 0,
) -> RunResult:
    save_dir = output_root / name
    save_dir.mkdir(parents=True, exist_ok=True)

    attempts = [first_batch]
    if fallback_batch != first_batch:
        attempts.append(fallback_batch)

    last_result: RunResult | None = None
    for batch_size in attempts:
        cmd = build_test_command(class_name, method, batch_size, save_dir, max_test_samples=max_test_samples)
        print(f"\n[run] {name}: class={class_name} method={method} batch={batch_size}")
        print(f"  log: {save_dir / 'runner_stdout.log'}")
        rc, out, err, elapsed, timed_out = run_command(cmd, timeout)
        (save_dir / "runner_stdout.log").write_text(out, encoding="utf-8", errors="replace")
        (save_dir / "runner_stderr.log").write_text(err, encoding="utf-8", errors="replace")
        metrics = parse_metric_table(f"{out}\n{err}", class_name)
        result = RunResult(
            name=name,
            class_name=class_name,
            method=method,
            batch_size=batch_size,
            elapsed_sec=round(elapsed, 3),
            returncode=rc,
            timed_out=timed_out,
            metrics=metrics,
            save_dir=str(save_dir),
            command=cmd,
        )
        last_result = result

        if result.ok:
            compact = " ".join(
                f"{col}={metrics[col]}" for col in METRIC_COLUMNS if col in metrics
            )
            print(f"  OK {elapsed:.1f}s {compact}")
            return result

        if timed_out:
            print(f"  TIMEOUT after {elapsed:.1f}s")
            print_tail(out or err, 16)
            return result

        if has_cuda_oom(out, err) and batch_size != fallback_batch:
            print("  CUDA OOM detected; retrying with smaller batch size.")
            continue

        print(f"  FAILED returncode={rc} elapsed={elapsed:.1f}s")
        if out.strip():
            print("  stdout tail:")
            print_tail(out, 12)
        if err.strip():
            print("  stderr tail:")
            print_tail(err, 12)
        return result

    assert last_result is not None
    return last_result


def mean_metric(results: Iterable[RunResult], method: str, metric: str) -> float | None:
    values: list[float] = []
    for result in results:
        if result.method != method or not result.ok:
            continue
        value = result.metrics.get(metric)
        if isinstance(value, (int, float)):
            values.append(float(value))
    if not values:
        return None
    return sum(values) / len(values)


def save_summary(output_root: Path, results: list[RunResult]) -> Path:
    output_root.mkdir(parents=True, exist_ok=True)
    out_file = output_root / "summary.json"
    payload = {
        "python": str(PYTHON),
        "repo": str(REPO),
        "checkpoint": CKPT_MVTEC,
        "results": [asdict(result) for result in results],
    }
    out_file.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return out_file


def print_summary(results: list[RunResult]) -> None:
    print("\n[summary]")
    print(f"{'name':<24} {'cls':<9} {'method':<8} {'batch':<5} {'ok':<5} {'I-AUROC':>8} {'I-AP':>8} {'P-AUROC':>8} {'P-AP':>8} {'P-F1':>8}")
    print("-" * 104)
    for result in results:
        metrics = result.metrics
        print(
            f"{result.name:<24} {result.class_name:<9} {result.method:<8} {result.batch_size:<5} "
            f"{str(result.ok):<5} "
            f"{metrics.get('I-AUROC', '')!s:>8} {metrics.get('I-AP', '')!s:>8} "
            f"{metrics.get('P-AUROC', '')!s:>8} {metrics.get('P-AP', '')!s:>8} "
            f"{metrics.get('P-F1max', '')!s:>8}"
        )


def run_smoke(output_root: Path, timeout: int, first_batch: int, fallback_batch: int, max_test_samples: int) -> list[RunResult]:
    return [
        run_experiment("smoke_candle_baseline_0s", "candle", "baseline", output_root, timeout, first_batch, fallback_batch, max_test_samples),
        run_experiment("smoke_candle_radapt_0s", "candle", "radapt", output_root, timeout, first_batch, fallback_batch, max_test_samples),
    ]


def run_visa3(output_root: Path, timeout: int, first_batch: int, fallback_batch: int, max_test_samples: int) -> list[RunResult]:
    results: list[RunResult] = []
    for class_name in ["candle", "capsules", "pcb1"]:
        results.append(
            run_experiment(
                f"visa3_{class_name}_baseline_0s",
                class_name,
                "baseline",
                output_root,
                timeout,
                first_batch,
                fallback_batch,
                max_test_samples,
            )
        )
        if not results[-1].ok:
            print("  stopping visa3: baseline failed")
            return results
        results.append(
            run_experiment(
                f"visa3_{class_name}_radapt_0s",
                class_name,
                "radapt",
                output_root,
                timeout,
                first_batch,
                fallback_batch,
                max_test_samples,
            )
        )
        if not results[-1].ok:
            print("  stopping visa3: R-AdaptCLIP failed")
            return results
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description="RTX 3070 low-risk R-AdaptCLIP runner")
    parser.add_argument("--phase", choices=["checks", "smoke", "visa3", "all"], default="all")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    parser.add_argument("--batch_size", type=int, default=DEFAULT_BATCH)
    parser.add_argument("--fallback_batch_size", type=int, default=FALLBACK_BATCH)
    parser.add_argument("--max_test_samples", type=int, default=0, help="balanced per-class cap for quick smoke runs")
    parser.add_argument("--output_root", type=Path, default=REPO / "results" / "rtx3070_lowrisk")
    args = parser.parse_args()

    if not PYTHON.exists():
        print(f"Interpreter not found: {PYTHON}")
        return 2
    if not REPO.exists():
        print(f"Repo not found: {REPO}")
        return 2

    all_results: list[RunResult] = []

    if args.phase in {"checks", "all"}:
        if not check_code(args.timeout):
            print("checks failed; stop before experiments")
            return 1
        if args.phase == "checks":
            return 0

    if args.phase in {"smoke", "all"}:
        smoke_results = run_smoke(args.output_root, args.timeout, args.batch_size, args.fallback_batch_size, args.max_test_samples)
        all_results.extend(smoke_results)
        print_summary(all_results)
        save_summary(args.output_root, all_results)
        if not all(result.ok for result in smoke_results):
            print("smoke failed; stop before visa3")
            return 1
        if args.phase == "smoke":
            return 0

    if args.phase in {"visa3", "all"}:
        visa3_results = run_visa3(args.output_root, args.timeout, args.batch_size, args.fallback_batch_size, args.max_test_samples)
        all_results.extend(visa3_results)
        print_summary(all_results)
        baseline_mean = mean_metric(visa3_results, "baseline", "I-AUROC")
        radapt_mean = mean_metric(visa3_results, "radapt", "I-AUROC")
        if baseline_mean is not None and radapt_mean is not None:
            print(f"\n[visa3] mean I-AUROC baseline={baseline_mean:.2f} radapt={radapt_mean:.2f} delta={radapt_mean - baseline_mean:+.2f}")
            if radapt_mean <= baseline_mean:
                print("[visa3] no image-level gain; do not expand to full VisA yet.")
        summary_file = save_summary(args.output_root, all_results)
        print(f"\nsummary saved: {summary_file}")
        return 0 if all(result.ok for result in visa3_results) else 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
