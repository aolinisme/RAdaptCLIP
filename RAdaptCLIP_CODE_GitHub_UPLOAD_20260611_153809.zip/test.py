"""Testing script for AdaptCLIP anomaly detection model."""

import argparse
import csv
import os
import pickle
import random
from collections import defaultdict

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter
from tabulate import tabulate
from tqdm import tqdm

import adaptcliplib
from adaptcliplib import PQAdapter, TextualAdapter, VisualAdapter, fusion_fun
from adaptcliplib.radapt_innovations import (
    SpectralResidualAnalyzer,
    mutual_consistency_scores,
    temperature_annealed_fusion,
    compute_meta_reliability,
)
from dataset import Dataset, PromptDataset
from tools import Evaluator, get_logger, get_transform, setup_seed, visualizer


def binary_entropy(prob, eps=1e-6):
    prob = prob.clamp(min=eps, max=1.0 - eps)
    return -(prob * torch.log(prob) + (1.0 - prob) * torch.log(1.0 - prob)) / np.log(2.0)


def uncertainty_weighted_pixel_fusion(tensor_list, eps=1e-6):
    if len(tensor_list) == 1:
        return tensor_list[0]
    stacked = torch.stack(tensor_list, dim=0)
    entropy_conf = 1.0 - binary_entropy(stacked)
    mean_map = stacked.mean(dim=0, keepdim=True)
    disagreement_conf = 1.0 - (stacked - mean_map).abs().clamp(0.0, 1.0)
    confidence = (entropy_conf * disagreement_conf).clamp_min(0.0) + eps
    return (stacked * confidence).sum(dim=0) / confidence.sum(dim=0)


def uncertainty_weighted_score_fusion(tensor_list, eps=1e-6):
    if len(tensor_list) == 1:
        return tensor_list[0]
    stacked = torch.stack(tensor_list, dim=0)
    entropy_conf = 1.0 - binary_entropy(stacked)
    mean_score = stacked.mean(dim=0, keepdim=True)
    disagreement_conf = 1.0 - (stacked - mean_score).abs().clamp(0.0, 1.0)
    confidence = (entropy_conf * disagreement_conf).clamp_min(0.0) + eps
    return (stacked * confidence).sum(dim=0) / confidence.sum(dim=0)


def map_confidence(anomaly_map):
    return (1.0 - binary_entropy(anomaly_map).flatten(1).mean(dim=1)).clamp(0.0, 1.0)


def score_confidence(anomaly_score):
    return (1.0 - binary_entropy(anomaly_score)).clamp(0.0, 1.0)


def disagreement_confidence(reference, candidate):
    return (1.0 - (reference - candidate).abs().flatten(1).mean(dim=1)).clamp(0.0, 1.0)


def prompt_weight_confidence(weights, eps=1e-6):
    if weights.shape[1] <= 1:
        return torch.ones(weights.shape[0], device=weights.device, dtype=weights.dtype)
    safe_weights = weights.clamp(min=eps)
    entropy = -(safe_weights * torch.log(safe_weights)).sum(dim=1) / np.log(weights.shape[1])
    return (1.0 - entropy).clamp(0.0, 1.0)


def confidence_gated_map_fusion(reference, candidate, confidence=None, max_weight=0.35,
                                min_confidence=0.05):
    if confidence is None:
        confidence = map_confidence(candidate) * disagreement_confidence(reference, candidate)
    denom = max(1.0 - float(min_confidence), 1e-6)
    gate = ((confidence - float(min_confidence)) / denom).clamp(0.0, 1.0)
    gate = gate * float(max_weight)
    return reference * (1.0 - gate[:, None, None]) + candidate * gate[:, None, None], gate


def risk_calibrated_pseudo_pixel_fusion(reference, candidate, pseudo_map, base_weight=0.1,
                                        max_weight=0.35, min_confidence=0.05,
                                        area_target=0.25, area_threshold=0.5):
    candidate_conf = map_confidence(candidate)
    pseudo_conf = map_confidence(pseudo_map)
    agreement_conf = disagreement_confidence(reference, candidate)

    area_ratio = (candidate > float(area_threshold)).float().flatten(1).mean(dim=1)
    area_target = max(float(area_target), 1e-6)
    area_conf = torch.where(
        area_ratio <= area_target,
        torch.ones_like(area_ratio),
        area_target / area_ratio.clamp_min(1e-6),
    ).clamp(0.0, 1.0)

    confidence = (candidate_conf * pseudo_conf * agreement_conf * area_conf).clamp(0.0, 1.0)
    denom = max(1.0 - float(min_confidence), 1e-6)
    normalized_conf = ((confidence - float(min_confidence)) / denom).clamp(0.0, 1.0)

    base_weight = max(float(base_weight), 0.0)
    max_weight = max(float(max_weight), base_weight)
    gate = normalized_conf * (base_weight + (max_weight - base_weight) * normalized_conf)
    fused = reference * (1.0 - gate[:, None, None]) + candidate * gate[:, None, None]

    diagnostics = dict(
        gate=gate.detach(),
        confidence=confidence.detach(),
        candidate_conf=candidate_conf.detach(),
        pseudo_conf=pseudo_conf.detach(),
        agreement_conf=agreement_conf.detach(),
        area_ratio=area_ratio.detach(),
        area_conf=area_conf.detach(),
    )
    return fused, gate, diagnostics


def confidence_gated_score_fusion(reference, candidate, confidence=None, max_weight=0.35,
                                  min_confidence=0.05):
    if confidence is None:
        confidence = score_confidence(candidate) * (1.0 - (reference - candidate).abs().clamp(0.0, 1.0))
    denom = max(1.0 - float(min_confidence), 1e-6)
    gate = ((confidence - float(min_confidence)) / denom).clamp(0.0, 1.0)
    gate = gate * float(max_weight)
    return reference * (1.0 - gate) + candidate * gate


def pearson_corr_1d(reference, candidate, eps=1e-6):
    reference = reference.float()
    candidate = candidate.float()
    ref_centered = reference - reference.mean()
    cand_centered = candidate - candidate.mean()
    denom = ref_centered.pow(2).mean().sqrt() * cand_centered.pow(2).mean().sqrt()
    if denom.item() < eps:
        return torch.tensor(0.0, device=reference.device, dtype=reference.dtype)
    return (ref_centered * cand_centered).mean() / denom.clamp_min(eps)


def apply_zero_rank_gate(results_eval, base_scores, pseudo_scores, max_weight=0.5, min_corr=0.0, logger=None):
    fused = base_scores.clone()
    cls_names = results_eval['cls_names']
    for cls_name in np.unique(cls_names):
        idx_np = cls_names == cls_name
        idx = torch.as_tensor(idx_np, device=base_scores.device, dtype=torch.bool)
        if idx.sum().item() < 3:
            gate = torch.tensor(0.0, device=base_scores.device, dtype=base_scores.dtype)
            corr = gate
        else:
            corr = pearson_corr_1d(base_scores[idx], pseudo_scores[idx]).clamp(-1.0, 1.0)
            denom = max(1.0 - float(min_corr), 1e-6)
            gate = ((corr - float(min_corr)) / denom).clamp(0.0, 1.0) * float(max_weight)
        fused[idx] = base_scores[idx] * (1.0 - gate) + pseudo_scores[idx] * gate
        if logger is not None:
            logger.info(f'Zero-shot rank gate cls={cls_name}: corr={float(corr):.4f}, gate={float(gate):.4f}')
    return fused


def compute_domain_shift_factor(base_scores, pseudo_scores, num_bins=50, sharpness=5.0):
    """
    Domain-Shift-Aware (DSA) Gate Factor.

    Measures the distributional distance between baseline and pseudo-normal
    anomaly score distributions using a discretized Wasserstein-1 metric.
    When baseline and pseudo distributions align closely (low W1 distance),
    the pseudo prototype is likely from the same visual domain, enabling
    higher gate ceiling. When distributions diverge (high W1 distance),
    domain shift is detected, and the gate ceiling is reduced to prevent
    negative transfer from out-of-domain pseudo prototypes.

    Returns:
        dsa_factor: (B,) in [0, 1]. 1.0 = same domain (trust pseudo more).
                    Values near 0 = domain shift detected (conservative gating).
    """
    B = base_scores.shape[0]
    if B < 10:
        return torch.full((B,), 0.5, device=base_scores.device, dtype=base_scores.dtype)

    base_sorted, _ = base_scores.sort()
    pseudo_sorted, _ = pseudo_scores.sort()

    # Discretized Wasserstein-1: average absolute difference of sorted scores
    w1_distance = (base_sorted - pseudo_sorted).abs().mean()

    # Normalize W1 by the score range for scale-invariance
    score_range = (base_scores.max() - base_scores.min()).clamp_min(1e-6)
    w1_normalized = (w1_distance / score_range).clamp(0.0, 1.0)

    # Map to domain-shift factor: low W1 → high factor (same domain)
    # Use sigmoid-like mapping: factor = 1 / (1 + exp(sharpness * (w1 - 0.5)))
    dsa_factor = torch.sigmoid(sharpness * (0.3 - w1_normalized))

    return dsa_factor.expand(B)


def domain_adaptive_max_weight(global_base_scores, global_pseudo_scores,
                                base_max_weight=0.5, min_max_weight=0.1,
                                dsa_sharpness=5.0, logger=None):
    """
    Compute domain-adaptive max_weight for zero-shot image score fusion.

    Combines DSA-gate (class-level domain alignment) with per-sample
    agreement to produce an adaptive ceiling for pseudo score contribution.

    Returns:
        adaptive_max_weight: (B,) per-sample max_weight in [min_max_weight, base_max_weight]
        dsa_factor: (B,) domain-shift factor for logging
    """
    dsa_factor = compute_domain_shift_factor(
        global_base_scores, global_pseudo_scores,
        sharpness=dsa_sharpness,
    )

    # Per-sample agreement: how close are base and pseudo scores?
    per_sample_agree = (1.0 - (global_base_scores - global_pseudo_scores).abs()).clamp(0.0, 1.0)

    # Adaptive max: blend DSA (class-level) with agreement (sample-level)
    adaptive_max = base_max_weight * dsa_factor * (0.5 + 0.5 * per_sample_agree)
    adaptive_max = adaptive_max.clamp(min=float(min_max_weight), max=float(base_max_weight))

    if logger is not None:
        logger.info(
            f'DSA-Gate: dsa_factor_mean={float(dsa_factor.mean()):.4f}, '
            f'adaptive_max_mean={float(adaptive_max.mean()):.4f}, '
            f'w1_normalized={float(compute_domain_shift_factor.__w1_cache__) if hasattr(compute_domain_shift_factor, "__w1_cache__") else "N/A"}'
        )

    return adaptive_max, dsa_factor


def normalize_prompt_scores(scores, temperature=1.0):
    temperature = max(float(temperature), 1e-6)
    finite_rows = torch.isfinite(scores).all(dim=1)
    safe_scores = torch.nan_to_num(scores, nan=0.0, posinf=0.0, neginf=0.0)
    weights = torch.softmax(safe_scores / temperature, dim=1)
    if not finite_rows.all():
        uniform = torch.full_like(weights, 1.0 / weights.shape[1])
        weights = torch.where(finite_rows[:, None], weights, uniform)
    return weights


def compute_prompt_reliability(query_feats, prompt_feats, local_maps, align_distances,
                               align_temperature=0.05, reliability_temperature=1.0):
    query_norm = F.normalize(query_feats, dim=-1)
    prompt_norm = F.normalize(prompt_feats, dim=-1)
    semantic = (F.cosine_similarity(query_norm.unsqueeze(1), prompt_norm, dim=-1) + 1.0) / 2.0

    align_tau = max(float(align_temperature), 1e-6)
    align_conf = torch.exp(-align_distances / align_tau)

    entropy_conf = 1.0 - binary_entropy(local_maps).flatten(2).mean(dim=-1)
    scores = 0.5 * semantic + 0.35 * align_conf + 0.15 * entropy_conf
    weights = normalize_prompt_scores(scores, temperature=reliability_temperature)
    return weights, scores


def apply_prompt_dropout(weights, scores, drop_quantile=0.25, min_keep=1, keep_topk=0, eps=1e-6):
    """Drop low-reliability prompts per query and renormalize remaining weights."""
    if weights.shape[1] <= 1:
        return weights
    min_keep = max(1, min(int(min_keep), weights.shape[1]))
    keep_topk = max(0, min(int(keep_topk), weights.shape[1]))
    safe_scores = torch.nan_to_num(scores, nan=-1e6, posinf=1e6, neginf=-1e6)

    if keep_topk > 0:
        keep_mask = torch.zeros_like(weights, dtype=torch.bool)
        topk_idx = torch.topk(safe_scores, k=keep_topk, dim=1).indices
        keep_mask.scatter_(1, topk_idx, True)
    else:
        drop_quantile = min(max(float(drop_quantile), 0.0), 0.95)
        threshold = torch.quantile(safe_scores.float(), drop_quantile, dim=1, keepdim=True)
        keep_mask = safe_scores >= threshold

    # Guarantee at least min_keep prompts even when scores are tied or invalid.
    topk_idx = torch.topk(safe_scores, k=min_keep, dim=1).indices
    topk_mask = torch.zeros_like(keep_mask, dtype=torch.bool)
    topk_mask.scatter_(1, topk_idx, True)
    keep_mask = keep_mask | topk_mask

    dropped = weights * keep_mask.to(weights.dtype)
    denom = dropped.sum(dim=1, keepdim=True)
    uniform = torch.full_like(weights, 1.0 / weights.shape[1])
    return torch.where(denom > eps, dropped / denom.clamp_min(eps), uniform)


def collapse_promptwise_outputs(global_logits, local_scores, align_scores, align_distances):
    prompt_local_maps = torch.stack([x[:, :, 1] for x in local_scores], dim=0).mean(dim=0)
    prompt_global_scores = torch.stack([x.softmax(-1)[:, :, 1] for x in global_logits], dim=0).mean(dim=0)
    prompt_align_maps = fusion_fun([x[:, :, 0] for x in align_scores], fusion_type='harmonic_mean')
    prompt_align_distances = torch.stack(align_distances, dim=0).mean(dim=0)
    return prompt_global_scores, prompt_local_maps, prompt_align_maps, prompt_align_distances


def collapse_standard_pq_outputs(global_logits, local_scores, align_scores):
    local_pq_map = torch.concat([x[:, 1].unsqueeze(1) for x in local_scores], dim=1).mean(dim=1).detach()
    align_score = fusion_fun(align_scores, fusion_type='harmonic_mean')[:, 0].detach()
    if isinstance(global_logits, list):
        global_pq_score = [x.softmax(-1).unsqueeze(-1) for x in global_logits]
        global_pq_score = torch.concat(global_pq_score, dim=-1).mean(dim=-1)[:, 1].detach()
    else:
        global_pq_score = global_logits.softmax(-1)[:, 1].detach()
    return global_pq_score, local_pq_map, align_score


def build_pseudo_prompt(query_feats, query_patch_feats, initial_map, keep_ratio=0.3):
    pseudo_patch_feats = []
    keep_ratio = min(max(float(keep_ratio), 1e-3), 1.0)

    for query_patch_feat in query_patch_feats:
        batch_size, token_num, dim = query_patch_feat.shape
        patch_tokens = query_patch_feat[:, 1:, :]
        patch_num = patch_tokens.shape[1]
        side = int(patch_num ** 0.5)
        patch_scores = F.interpolate(initial_map[:, None], size=(side, side), mode='bilinear', align_corners=False)
        patch_scores = patch_scores.flatten(1)
        keep_num = max(1, int(patch_num * keep_ratio))
        keep_idx = torch.topk(patch_scores, k=keep_num, dim=1, largest=False).indices
        selected = torch.gather(patch_tokens, dim=1, index=keep_idx.unsqueeze(-1).expand(-1, -1, dim))
        prototype = selected.mean(dim=1)
        prototype = F.normalize(prototype, dim=-1)
        repeated_proto = prototype.unsqueeze(1).expand(-1, patch_num, -1)
        pseudo_patch_feat = torch.cat([query_patch_feat[:, :1, :], repeated_proto], dim=1).unsqueeze(1)
        pseudo_patch_feats.append(pseudo_patch_feat)

    pseudo_feats = query_feats.unsqueeze(1)
    return pseudo_feats, pseudo_patch_feats


def limit_records_balanced(records, max_samples_per_class):
    max_samples_per_class = int(max_samples_per_class)
    if max_samples_per_class <= 0:
        return records

    grouped = defaultdict(list)
    for record in records:
        grouped[record['cls_name']].append(record)

    limited = []
    for cls_name in grouped:
        cls_records = grouped[cls_name]
        normal = [x for x in cls_records if int(x.get('anomaly', 0)) == 0]
        anomaly = [x for x in cls_records if int(x.get('anomaly', 0)) != 0]
        if normal and anomaly:
            normal_budget = max(1, max_samples_per_class // 2)
            anomaly_budget = max_samples_per_class - normal_budget
            if anomaly_budget <= 0:
                anomaly_budget = 1
                normal_budget = max(0, max_samples_per_class - anomaly_budget)
            limited.extend(normal[:normal_budget])
            limited.extend(anomaly[:anomaly_budget])
        else:
            limited.extend(cls_records[:max_samples_per_class])
    return limited


def save_prompt_weight_records(save_path, filename, records):
    os.makedirs(save_path, exist_ok=True)
    weight_path = os.path.join(save_path, filename)
    with open(weight_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['sample_id', 'cls_name', 'query_path', 'weights', 'scores'])
        writer.writeheader()
        writer.writerows(records)


def save_risk_gate_records(save_path, filename, records):
    os.makedirs(save_path, exist_ok=True)
    gate_path = os.path.join(save_path, filename)
    fieldnames = [
        'sample_id',
        'cls_name',
        'query_path',
        'gate',
        'confidence',
        'candidate_conf',
        'pseudo_conf',
        'agreement_conf',
        'area_ratio',
        'area_conf',
    ]
    with open(gate_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)


def prompt_association(image_memory, patch_memory, target_class_name):
    patch_level_num = len(patch_memory[target_class_name[0]])
    retrive_image = []
    retrive_patch = [[] for i in range(patch_level_num)]

    for class_name in target_class_name:
        retrive_image.append(image_memory[class_name])  # S*D
        for l in range(patch_level_num):
            retrive_patch[l].append(patch_memory[class_name][l]) #

    retrive_image = torch.stack(retrive_image)  # B*S*D
    for l in range(patch_level_num):
        retrive_patch[l] = torch.stack(retrive_patch[l])  # B*S*L*D
    return retrive_image, retrive_patch


def build_prompt_memory(model, prompt_dataloader, device, obj_list, view_list, features_list, DPAM_layer):
    """Build few-shot prompt memory."""
    # initialize_memory
    feats_scale_num = len(features_list)
    prompt_image_memory = {}
    prompt_patch_memory = {}

    image_temp = []
    patch_temp = [[] for i in range(feats_scale_num)]
    cls_names_temp = []
    view_ids_temp = []

    for idx, items in enumerate(tqdm(prompt_dataloader)):
        cls_name = items['cls_name']
        prompt_image = items['img'].to(device)  # B*s*c*h*w
        prompt_mask = items['img_mask'].to(device)
        view_id = items['view_id']

        with torch.no_grad():
            image_feat, patch_feat = model.encode_image(prompt_image, features_list, DPAM_layer = DPAM_layer)

        cls_names_temp.extend(cls_name)
        image_temp.append(image_feat)
        view_ids_temp.extend(view_id)

        for i in range(feats_scale_num):
            patch_temp[i].append(patch_feat[i])


    image_temp = torch.cat(image_temp, dim=0)
    for i in range(feats_scale_num):
        patch_temp[i] = torch.cat(patch_temp[i], dim=0)

    for obj in obj_list:
        if len(view_list) > 1:
            for view_id in view_list:
                indice = (np.array(cls_names_temp) == obj) & (np.array(view_ids_temp) == view_id)
                obj_name = obj + '_' + view_id

                prompt_image_memory[obj_name] = image_temp[indice]
                prompt_patch_memory[obj_name] = []

                for i in range(feats_scale_num):
                    prompt_patch_memory[obj_name].append(patch_temp[i][[indice]])
        else:
            indice = (np.array(cls_names_temp) == obj)
            obj_name = obj

            prompt_image_memory[obj_name] = image_temp[indice]
            prompt_patch_memory[obj_name] = []

            for i in range(feats_scale_num):
                prompt_patch_memory[obj_name].append(patch_temp[i][[indice]])

    return prompt_image_memory, prompt_patch_memory


def test(args):
    img_size = args.image_size
    features_list = args.features_list
    dataset_dir = args.test_data_path
    save_path = args.save_path
    dataset_name = args.dataset
    batch_size = args.batch_size
    k_shots = args.k_shots
    seed = args.seed
    vl_reduction = args.vl_reduction
    pq_mid_dim = args.pq_mid_dim
    pq_context = args.pq_context
    eval_metrics =  args.eval_metrics
    structure_align = args.structure_align or ('local_soft_topk' if args.radaptclip and k_shots > 0 else 'soft_topk' if args.radaptclip else 'original')
    pseudo_structure_align = args.pseudo_structure_align or 'soft_topk'
    use_prompt_reliability = args.radaptclip if args.use_prompt_reliability is None else args.use_prompt_reliability
    use_pseudo_prompt = args.radaptclip if args.use_pseudo_prompt is None else args.use_pseudo_prompt
    use_uncertainty_fusion = args.radaptclip if args.use_uncertainty_fusion is None else args.use_uncertainty_fusion
    use_pixel_gate = args.radaptclip if args.use_pixel_gate is None else args.use_pixel_gate
    use_pixel_fallback = args.radaptclip if args.use_pixel_fallback is None else args.use_pixel_fallback
    use_pseudo_pixel = False if args.use_pseudo_pixel is None else args.use_pseudo_pixel
    use_risk_calibrated_pseudo_pixel = False if args.use_risk_calibrated_pseudo_pixel is None else args.use_risk_calibrated_pseudo_pixel
    use_decoupled_image_pixel = args.use_decoupled_image_pixel
    image_pixel_gate_max_weight = args.pixel_gate_max_weight if args.image_pixel_gate_max_weight is None else args.image_pixel_gate_max_weight
    image_pixel_gate_min_confidence = args.pixel_gate_min_confidence if args.image_pixel_gate_min_confidence is None else args.image_pixel_gate_min_confidence
    mode = 'test'

    log_file = f'{dataset_name}_{seed}seed_{k_shots}shot_{mode}_log.txt'
    logger = get_logger(save_path, log_file)
    if args.radaptclip:
        logger.info(
            f'R-AdaptCLIP config: structure_align={structure_align}, align_topk={args.align_topk}, '
            f'pseudo_structure_align={pseudo_structure_align}, align_window={args.align_window}, uncertainty_fusion={use_uncertainty_fusion}, '
            f'pixel_gate={use_pixel_gate}, pixel_fallback={use_pixel_fallback}, '
            f'decoupled_image_pixel={use_decoupled_image_pixel}, image_pixel_gate_max={image_pixel_gate_max_weight}, '
            f'pseudo_prompt={use_pseudo_prompt}, pseudo_pixel={use_pseudo_pixel}, '
            f'risk_calibrated_pseudo_pixel={use_risk_calibrated_pseudo_pixel}'
        )
        if use_risk_calibrated_pseudo_pixel:
            logger.info(
                f'Risk-calibrated pseudo pixel gate: base={args.risk_gate_base_weight}, '
                f'max={args.risk_gate_max_weight}, min_conf={args.risk_gate_min_confidence}, '
                f'area_target={args.risk_gate_area_target}, area_threshold={args.risk_gate_area_threshold}'
            )

    device = "cuda" if torch.cuda.is_available() else "cpu"
    if args.pretrained_model == 'ViT-L/14@336px':
        model, _ = adaptcliplib.load(args.pretrained_model, device=device)
        model.visual.DAPM_replace(DPAM_layer = 20)
        patch_size = 14
        input_dim = 768
        DPAM_layer = 20
    if args.pretrained_model == 'VITB16_PLUS_240':
        model, _ = adaptcliplib.load(args.pretrained_model, device=device)
        model.visual.DAPM_replace(DPAM_layer = 10)
        patch_size = 16
        input_dim = 640
        DPAM_layer = 10

    preprocess, target_transform = get_transform(image_size=args.image_size)
    if dataset_name in ['Real-IAD-Variety', 'RealIAD']:
        sample_level = True
        prompt_data = PromptDataset(root=dataset_dir, transform=preprocess, target_transform=target_transform, \
                                    dataset_name=dataset_name, k_shots=k_shots, save_dir=save_path, mode=mode, \
                                    seed=seed, class_name=args.class_name)
        test_data = Dataset(root=dataset_dir, transform=preprocess, target_transform=target_transform, \
                            dataset_name=dataset_name, k_shots=k_shots, save_dir=save_path, mode=mode, \
                            seed=seed, class_name=args.class_name)
    else:
        prompt_data = PromptDataset(root=dataset_dir, transform=preprocess, target_transform=target_transform, \
                                    dataset_name=dataset_name, k_shots=k_shots, save_dir=save_path, mode=mode, seed=seed, \
                                    class_name=args.class_name)
        test_data = Dataset(root=dataset_dir, transform=preprocess, target_transform=target_transform, \
                            dataset_name=dataset_name, k_shots=k_shots, save_dir=save_path, mode=mode, seed=seed, \
                            class_name=args.class_name)
        sample_level = False
    if args.max_test_samples > 0:
        test_data.data_all = limit_records_balanced(test_data.data_all, args.max_test_samples)
        test_data.length = len(test_data.data_all)
    prompt_dataloader = torch.utils.data.DataLoader(prompt_data, batch_size=batch_size, shuffle=False)
    test_dataloader = torch.utils.data.DataLoader(test_data, batch_size=batch_size, shuffle=False, num_workers=args.num_workers)
    obj_list = test_data.obj_list
    view_list = test_data.view_list

    # ====================== Init Adapters ======================
    textual_learner = TextualAdapter(model.to("cpu"), img_size, args.n_ctx)
    visual_learner = VisualAdapter(img_size, patch_size, input_dim=input_dim, reduction=vl_reduction)
    pq_learner = PQAdapter(img_size, patch_size, context=pq_context, input_dim=input_dim, mid_dim=pq_mid_dim, layers_num=len(features_list))


    logger.info('\n' + "loading model from: " + args.checkpoint_path)
    checkpoint_adapter = torch.load(args.checkpoint_path)
    textual_learner.load_state_dict(checkpoint_adapter["textual_learner"])
    visual_learner.load_state_dict(checkpoint_adapter["visual_learner"])
    pq_learner.load_state_dict(checkpoint_adapter["pq_learner"])


    model.to(device)
    textual_learner.to(device)
    visual_learner.to(device)
    pq_learner.to(device)

    model.eval()
    textual_learner.eval()
    visual_learner.eval()
    pq_learner.eval()

    # Init SRA module
    sra_module = SpectralResidualAnalyzer(input_dim=input_dim, num_bands=3, mid_dim=64).to(device) if args.use_sra else None
    if sra_module:
        sra_module.eval()

    textual_learner_parameters = sum(p.numel() for p in textual_learner.parameters())
    visual_learner_parameters = sum(p.numel() for p in visual_learner.parameters())
    pq_learner_parameters = sum(p.numel() for p in pq_learner.parameters())
    sra_parameters = sum(p.numel() for p in sra_module.parameters()) if sra_module else 0

    learned_parameters = textual_learner_parameters + visual_learner_parameters + pq_learner_parameters + sra_parameters
    fixed_parameters = sum(p.numel() for p in model.parameters())


    print(f"textual_learner params:{(textual_learner_parameters):.0f}",
          f"visual_learner params:{(visual_learner_parameters)/1e+6:.1f}M",
          f"pq_learner params:{(pq_learner_parameters)/1e+6:.1f}M",
          f"sra params:{sra_parameters}",
          f"learned all parameters:{(learned_parameters)/1e+6:.1f}M",
          f"fixed params:{(fixed_parameters)/1e+6:.1f}M",
          f"all params:{(learned_parameters+fixed_parameters)/1e+6:.1f}M"
     )


    # ====================== Initialize Evaluation Metrics ======================
    cpu_eva = False
    if cpu_eva:
        evaluator = Evaluator('cpu', metrics=eval_metrics, sample_level=sample_level)
    else:
        evaluator = Evaluator(device, metrics=eval_metrics, sample_level=sample_level)

    # ======================Text Encoder forward ======================
    textual_learner.prepare_static_text_feature(model)
    static_text_features = textual_learner.static_text_features

    learned_prompts, tokenized_prompts = textual_learner()
    learned_text_features = model.encode_text_learn(learned_prompts, tokenized_prompts).float()


    # ====================== Few-shot Prompt Memory ======================
    if k_shots > 0:
        prompt_image_memory, prompt_patch_memory = build_prompt_memory(model, prompt_dataloader, device, obj_list, view_list, args.features_list, DPAM_layer)


    # ====================== Visual and Learner forward ======================
    sample_ids, gt_masks, pr_masks, cls_names, gt_anomalys, pr_anomalys, query_paths = [], [], [], [], [], [], []
    rank_base_pr_anomalys, rank_pseudo_pr_anomalys = [], []
    prompt_weight_records = []
    risk_gate_records = []
    # nums = 0
    # total_time = 0
    for idx, items in enumerate(tqdm(test_dataloader)):
        query_image = items['img'].to(device)
        current_batchsize = query_image.shape[0]
        query_path = items['img_path']

        cls_name = items['cls_name']
        cls_id = items['cls_id']
        sample_id = items['sample_id']

        gt_anomaly = items['anomaly'].to(device)
        gt_mask = items['img_mask'][:, 0]
        gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
        gt_mask = gt_mask.to(device)

        # torch.cuda.synchronize()
        # start_time = time.time()

        with torch.no_grad():
            query_feats, query_patch_feats = model.encode_image(query_image, args.features_list, DPAM_layer = DPAM_layer)

        rank_base_image_pred, rank_pseudo_image_pred = None, None

        if k_shots > 0:
            if len(view_list) > 1:
                target_cls_name = [cls_name + '_' + view_id for cls_name, view_id in zip(cls_name, items['view_id'])]
            else:
                target_cls_name = cls_name
            prompt_feats, prompt_patch_feats = prompt_association(prompt_image_memory, prompt_patch_memory, target_cls_name)

        # ====================== CLIP Baseline ======================
        '''
        global_logit, local_map = textual_learner.compute_global_local_score(query_feats, query_patch_feats, static_text_features)
        local_map = local_map[:, 1].detach()

        global_score = global_logit.softmax(-1)
        global_score = global_score[:, 1].detach()
        '''

        # ====================== visual_adapter ======================
        if args.visual_learner:
            global_vl_logit, local_vl_map = visual_learner(query_feats, query_patch_feats, static_text_features)
            local_vl_map = local_vl_map[:, 1].detach()

            global_vl_score = global_vl_logit.softmax(-1)
            global_vl_score = global_vl_score[:, 1].detach()

        # ====================== textual_adapter ======================
        if args.textual_learner:
            global_tl_logit, local_tl_map = textual_learner.compute_global_local_score(query_feats, query_patch_feats, learned_text_features)
            local_tl_map = local_tl_map[:, 1].detach()

            global_tl_score = global_tl_logit.softmax(-1)
            global_tl_score = global_tl_score[:, 1].detach()

        # ====================== pq_adapter ======================
        baseline_global_pq_score, baseline_local_pq_map, baseline_align_score = None, None, None
        prompt_weights = None
        if args.pq_learner and k_shots > 0:
            if args.radaptclip:
                if use_pixel_fallback:
                    baseline_global_pq_logit, baseline_local_pq_list, baseline_align_score_list = pq_learner(
                        query_feats,
                        query_patch_feats,
                        prompt_feats,
                        prompt_patch_feats,
                    )
                    baseline_global_pq_score, baseline_local_pq_map, baseline_align_score = collapse_standard_pq_outputs(
                        baseline_global_pq_logit,
                        baseline_local_pq_list,
                        baseline_align_score_list,
                    )

                global_pq_logit, local_pq_map_list, align_score_list, align_distances = pq_learner.forward_promptwise(
                    query_feats,
                    query_patch_feats,
                    prompt_feats,
                    prompt_patch_feats,
                    structure_align=structure_align,
                    align_topk=args.align_topk,
                    align_temperature=args.align_temperature,
                    align_window=args.align_window,
                    align_spatial_weight=args.align_spatial_weight,
                )
                prompt_global_scores, prompt_local_maps, prompt_align_maps, prompt_align_distances = collapse_promptwise_outputs(
                    global_pq_logit,
                    local_pq_map_list,
                    align_score_list,
                    align_distances,
                )

                if use_prompt_reliability:
                    if args.use_meta_reliability:
                        # Meta-Reliability: HRD + MCV combined
                        prompt_weights, prompt_scores, mcv_scores, _ = compute_meta_reliability(
                            query_feats, prompt_feats, prompt_local_maps, prompt_align_distances,
                            global_pq_logit, local_pq_map_list, align_score_list,
                            align_temperature=args.align_temperature,
                            reliability_temperature=args.reliability_temperature,
                        )
                    elif args.use_mcv:
                        # HRD + MCV blended
                        mcv_scores, _ = mutual_consistency_scores(
                            global_pq_logit, local_pq_map_list, align_score_list)
                        _, prompt_scores = compute_prompt_reliability(
                            query_feats, prompt_feats, prompt_local_maps, prompt_align_distances,
                            align_temperature=args.align_temperature,
                            reliability_temperature=args.reliability_temperature,
                        )
                        blended = 0.7 * prompt_scores + 0.3 * mcv_scores
                        prompt_weights = normalize_prompt_scores(blended, temperature=args.reliability_temperature)
                    else:
                        prompt_weights, prompt_scores = compute_prompt_reliability(
                            query_feats,
                            prompt_feats,
                            prompt_local_maps,
                            prompt_align_distances,
                            align_temperature=args.align_temperature,
                            reliability_temperature=args.reliability_temperature,
                        )
                else:
                    prompt_scores = torch.zeros_like(prompt_global_scores)
                    prompt_weights = torch.full_like(prompt_global_scores, 1.0 / prompt_global_scores.shape[1])
                if args.use_prompt_dropout and prompt_weights.shape[1] > 1:
                    prompt_weights = apply_prompt_dropout(
                        prompt_weights,
                        prompt_scores,
                        drop_quantile=args.prompt_dropout_quantile,
                        min_keep=args.prompt_dropout_min_keep,
                        keep_topk=args.prompt_keep_topk,
                    )
                prompt_weights = prompt_weights.detach()
                prompt_scores = prompt_scores.detach()

                # Temperature-Annealed Fusion (TAF) or standard weighted sum
                if args.use_taf and prompt_weights.shape[1] > 1:
                    local_pq_map, _ = temperature_annealed_fusion(
                        prompt_local_maps, None, prompt_weights,
                        base_temperature=args.reliability_temperature,
                        min_temperature=0.1, max_temperature=5.0)
                    global_pq_score, _ = temperature_annealed_fusion(
                        prompt_global_scores, None, prompt_weights,
                        base_temperature=args.reliability_temperature,
                        min_temperature=0.1, max_temperature=5.0)
                    align_score = (prompt_align_maps * prompt_weights[:, :, None, None]).sum(dim=1).detach()
                else:
                    local_pq_map = (prompt_local_maps * prompt_weights[:, :, None, None]).sum(dim=1).detach()
                    align_score = (prompt_align_maps * prompt_weights[:, :, None, None]).sum(dim=1).detach()
                    global_pq_score = (prompt_global_scores * prompt_weights).sum(dim=1).detach()

                if args.save_prompt_weights:
                    weights_cpu = prompt_weights.detach().cpu().numpy()
                    scores_cpu = prompt_scores.detach().cpu().numpy()
                    for sample_idx in range(current_batchsize):
                        prompt_weight_records.append({
                            'sample_id': str(sample_id[sample_idx]),
                            'cls_name': str(cls_name[sample_idx]),
                            'query_path': str(query_path[sample_idx]),
                            'weights': ';'.join([f'{x:.6f}' for x in weights_cpu[sample_idx]]),
                            'scores': ';'.join([f'{x:.6f}' for x in scores_cpu[sample_idx]]),
                        })
            else:
                global_pq_logit, local_pq_map_list, align_score_list = pq_learner(query_feats, query_patch_feats, prompt_feats, prompt_patch_feats)
                global_pq_score, local_pq_map, align_score = collapse_standard_pq_outputs(
                    global_pq_logit,
                    local_pq_map_list,
                    align_score_list,
                )

        local_pseudo_map, global_pseudo_score = None, None
        if args.radaptclip and use_pseudo_prompt and args.pq_learner and k_shots == 0:
            initial_zero_map = fusion_fun([local_vl_map, local_tl_map], fusion_type=args.fusion_type).detach()
            pseudo_feats, pseudo_patch_feats = build_pseudo_prompt(
                query_feats,
                query_patch_feats,
                initial_zero_map,
                keep_ratio=args.pseudo_keep_ratio,
            )
            global_pseudo_logit, local_pseudo_map_list, align_pseudo_score_list, align_pseudo_distances = pq_learner.forward_promptwise(
                query_feats,
                query_patch_feats,
                pseudo_feats,
                pseudo_patch_feats,
                structure_align=pseudo_structure_align,
                align_topk=args.align_topk,
                align_temperature=args.align_temperature,
                align_window=args.align_window,
                align_spatial_weight=args.align_spatial_weight,
            )
            prompt_global_scores, prompt_local_maps, _, _ = collapse_promptwise_outputs(
                global_pseudo_logit,
                local_pseudo_map_list,
                align_pseudo_score_list,
                align_pseudo_distances,
            )
            local_pseudo_map = prompt_local_maps[:, 0].detach()
            global_pseudo_score = prompt_global_scores[:, 0].detach()

        if k_shots > 0:
            base_local_pq_map = baseline_local_pq_map if baseline_local_pq_map is not None else local_pq_map
            base_align_score = baseline_align_score if baseline_align_score is not None else align_score
            base_global_pq_score = baseline_global_pq_score if baseline_global_pq_score is not None else global_pq_score

            base_pixel_map = fusion_fun([local_vl_map, local_tl_map, base_local_pq_map], fusion_type=args.fusion_type)
            base_pixel_map = fusion_fun([base_pixel_map, base_align_score], fusion_type='harmonic_mean')

            if args.radaptclip:
                if use_uncertainty_fusion:
                    radapt_pixel_map = uncertainty_weighted_pixel_fusion([local_vl_map, local_tl_map, local_pq_map])
                else:
                    radapt_pixel_map = fusion_fun([local_vl_map, local_tl_map, local_pq_map], fusion_type=args.fusion_type)
                radapt_pixel_map = fusion_fun([radapt_pixel_map, align_score], fusion_type='harmonic_mean')
                if prompt_weights is not None:
                    reliability_conf = 0.5 + 0.5 * prompt_weight_confidence(prompt_weights)
                else:
                    reliability_conf = torch.ones(current_batchsize, device=device)
                pixel_conf = map_confidence(radapt_pixel_map) * disagreement_confidence(base_pixel_map, radapt_pixel_map) * reliability_conf
                if use_pixel_gate:
                    pixel_anomaly_map, _ = confidence_gated_map_fusion(
                        base_pixel_map,
                        radapt_pixel_map,
                        confidence=pixel_conf,
                        max_weight=args.pixel_gate_max_weight,
                        min_confidence=args.pixel_gate_min_confidence,
                    )
                else:
                    pixel_anomaly_map = radapt_pixel_map
            else:
                pixel_anomaly_map = base_pixel_map
            pixel_anomaly_map = torch.stack([torch.from_numpy(gaussian_filter(i, sigma = args.sigma)) for i in pixel_anomaly_map.detach().cpu()], dim = 0)
            pixel_anomaly_map = pixel_anomaly_map.to(device)

            # get image level prediction
            if args.radaptclip and use_decoupled_image_pixel:
                image_support_pixel_map, _ = confidence_gated_map_fusion(
                    base_pixel_map,
                    radapt_pixel_map,
                    confidence=pixel_conf,
                    max_weight=image_pixel_gate_max_weight,
                    min_confidence=image_pixel_gate_min_confidence,
                )
                base_image_pixel_map = torch.stack([torch.from_numpy(gaussian_filter(i, sigma=args.sigma)) for i in base_pixel_map.detach().cpu()], dim=0).to(device)
                radapt_image_pixel_map = torch.stack([torch.from_numpy(gaussian_filter(i, sigma=args.sigma)) for i in image_support_pixel_map.detach().cpu()], dim=0).to(device)
                base_anomaly_map_max, _ = torch.max(base_image_pixel_map.view(current_batchsize, -1), dim=1)
                radapt_anomaly_map_max, _ = torch.max(radapt_image_pixel_map.view(current_batchsize, -1), dim=1)
            else:
                anomaly_map_max, _ = torch.max(pixel_anomaly_map.view(current_batchsize, -1), dim=1)
                base_anomaly_map_max = anomaly_map_max
                radapt_anomaly_map_max = anomaly_map_max
            base_image_pred = fusion_fun([global_vl_score, global_tl_score, base_global_pq_score], fusion_type=args.fusion_type)
            base_image_pred = fusion_fun([base_image_pred, base_anomaly_map_max], fusion_type="harmonic_mean")
            if args.radaptclip:
                if use_uncertainty_fusion:
                    radapt_image_pred = uncertainty_weighted_score_fusion([global_vl_score, global_tl_score, global_pq_score])
                else:
                    radapt_image_pred = fusion_fun([global_vl_score, global_tl_score, global_pq_score], fusion_type=args.fusion_type)
                radapt_image_pred = fusion_fun([radapt_image_pred, radapt_anomaly_map_max], fusion_type="harmonic_mean")
                image_conf = score_confidence(radapt_image_pred) * (0.5 + 0.5 * reliability_conf)
                image_anomaly_pred = confidence_gated_score_fusion(
                    base_image_pred,
                    radapt_image_pred,
                    confidence=image_conf,
                    max_weight=args.image_gate_max_weight,
                    min_confidence=args.image_gate_min_confidence,
                )
            else:
                image_anomaly_pred = base_image_pred

        else:
            # get pixel level prediction
            base_pixel_map = fusion_fun([local_vl_map, local_tl_map], fusion_type=args.fusion_type)
            zero_pixel_maps = [local_vl_map, local_tl_map]
            if local_pseudo_map is not None and use_pseudo_pixel:
                zero_pixel_maps.append(local_pseudo_map)
            zero_score_maps = [local_vl_map, local_tl_map]
            if local_pseudo_map is not None:
                zero_score_maps.append(local_pseudo_map)
            if args.radaptclip:
                if use_uncertainty_fusion:
                    radapt_pixel_map = uncertainty_weighted_pixel_fusion(zero_pixel_maps)
                else:
                    radapt_pixel_map = fusion_fun(zero_pixel_maps, fusion_type=args.fusion_type)
                if use_pixel_gate:
                    if use_risk_calibrated_pseudo_pixel and local_pseudo_map is not None and use_pseudo_pixel:
                        pixel_anomaly_map, _, risk_diagnostics = risk_calibrated_pseudo_pixel_fusion(
                            base_pixel_map,
                            radapt_pixel_map,
                            local_pseudo_map,
                            base_weight=args.risk_gate_base_weight,
                            max_weight=args.risk_gate_max_weight,
                            min_confidence=args.risk_gate_min_confidence,
                            area_target=args.risk_gate_area_target,
                            area_threshold=args.risk_gate_area_threshold,
                        )
                        if args.save_risk_gates:
                            diagnostics_cpu = {k: v.detach().cpu().numpy() for k, v in risk_diagnostics.items()}
                            for i in range(current_batchsize):
                                risk_gate_records.append({
                                    'sample_id': sample_id[i],
                                    'cls_name': cls_name[i],
                                    'query_path': query_path[i],
                                    'gate': float(diagnostics_cpu['gate'][i]),
                                    'confidence': float(diagnostics_cpu['confidence'][i]),
                                    'candidate_conf': float(diagnostics_cpu['candidate_conf'][i]),
                                    'pseudo_conf': float(diagnostics_cpu['pseudo_conf'][i]),
                                    'agreement_conf': float(diagnostics_cpu['agreement_conf'][i]),
                                    'area_ratio': float(diagnostics_cpu['area_ratio'][i]),
                                    'area_conf': float(diagnostics_cpu['area_conf'][i]),
                                })
                    else:
                        pixel_conf = map_confidence(radapt_pixel_map) * disagreement_confidence(base_pixel_map, radapt_pixel_map)
                        pixel_anomaly_map, _ = confidence_gated_map_fusion(
                            base_pixel_map,
                            radapt_pixel_map,
                            confidence=pixel_conf,
                            max_weight=args.pixel_gate_max_weight,
                            min_confidence=args.pixel_gate_min_confidence,
                        )
                else:
                    pixel_anomaly_map = radapt_pixel_map
            else:
                pixel_anomaly_map = base_pixel_map

            pixel_anomaly_map = torch.stack([torch.from_numpy(gaussian_filter(i, sigma = args.sigma)) for i in pixel_anomaly_map.detach().cpu()], dim = 0)
            pixel_anomaly_map = pixel_anomaly_map.to(device)

            # get image level prediction
            base_anomaly_map_max, _ = torch.max(pixel_anomaly_map.view(current_batchsize, -1), dim=1)
            base_image_pred = fusion_fun([global_vl_score, global_tl_score, base_anomaly_map_max], fusion_type=args.fusion_type)
            pseudo_image_pred = base_image_pred
            if args.radaptclip and local_pseudo_map is not None:
                if use_uncertainty_fusion:
                    image_score_map = uncertainty_weighted_pixel_fusion(zero_score_maps)
                else:
                    image_score_map = fusion_fun(zero_score_maps, fusion_type=args.fusion_type)
                image_score_map = torch.stack([torch.from_numpy(gaussian_filter(i, sigma=args.sigma)) for i in image_score_map.detach().cpu()], dim=0)
                image_score_map = image_score_map.to(device)
                anomaly_map_max, _ = torch.max(image_score_map.view(current_batchsize, -1), dim=1)
                zero_global_scores = [global_vl_score, global_tl_score, anomaly_map_max]
                if global_pseudo_score is not None:
                    zero_global_scores.append(global_pseudo_score)
                if use_uncertainty_fusion:
                    pseudo_image_pred = uncertainty_weighted_score_fusion(zero_global_scores)
                else:
                    pseudo_image_pred = fusion_fun(zero_global_scores, fusion_type=args.fusion_type)
                if args.use_zero_image_gate:
                    pseudo_conf = score_confidence(pseudo_image_pred) * (1.0 - (base_image_pred - pseudo_image_pred).abs().clamp(0.0, 1.0))
                    image_anomaly_pred = confidence_gated_score_fusion(
                        base_image_pred,
                        pseudo_image_pred,
                        confidence=pseudo_conf,
                        max_weight=args.image_gate_max_weight,
                        min_confidence=args.image_gate_min_confidence,
                    )
                elif args.use_dsa_gate:
                    # DSA-Gate: domain-shift-aware adaptive fusion ceiling
                    adaptive_max, dsa_factor = domain_adaptive_max_weight(
                        base_image_pred, pseudo_image_pred,
                        base_max_weight=args.image_gate_max_weight,
                        min_max_weight=args.dsa_gate_min_weight,
                        dsa_sharpness=args.dsa_gate_sharpness,
                        logger=logger,
                    )
                    pseudo_conf = score_confidence(pseudo_image_pred) * (1.0 - (base_image_pred - pseudo_image_pred).abs().clamp(0.0, 1.0))
                    image_anomaly_pred = confidence_gated_score_fusion(
                        base_image_pred, pseudo_image_pred,
                        confidence=pseudo_conf,
                        max_weight=adaptive_max,
                        min_confidence=args.image_gate_min_confidence,
                    )
                else:
                    image_anomaly_pred = pseudo_image_pred
            else:
                image_anomaly_pred = base_image_pred
            rank_base_image_pred = base_image_pred.detach()
            rank_pseudo_image_pred = pseudo_image_pred.detach()


        if dataset_name in ['Real-IAD-Variety', 'RealIAD', 'bmad-medical']:
            resize_mask = 256
            if resize_mask is not None:
                pixel_anomaly_map = F.interpolate(pixel_anomaly_map[:, None], size=(resize_mask, resize_mask), mode='bilinear', align_corners=False)
                pixel_anomaly_map = pixel_anomaly_map[:, 0]
                gt_mask = F.interpolate(gt_mask[:, None], size=(resize_mask, resize_mask), mode='nearest')
                gt_mask = gt_mask.bool().int()

        pixel_anomaly_map  = torch.nan_to_num(pixel_anomaly_map,  nan=0.0, posinf=0.0, neginf=0.0)
        image_anomaly_pred = torch.nan_to_num(image_anomaly_pred, nan=0.0, posinf=0.0, neginf=0.0)

        if args.save_visuals:
            visualizer(query_path, query_image.detach().cpu(), pixel_anomaly_map.detach().cpu(), \
                       (img_size, img_size), save_path, cls_name, gt_mask.detach().cpu()[:, None])

        sample_ids.append(np.array(sample_id))
        cls_names.append(np.array(cls_name))
        query_paths.append(np.array(query_path))
        if cpu_eva:
            gt_masks.append(gt_mask.int().cpu())
            pr_masks.append(pixel_anomaly_map.cpu())

            gt_anomalys.append(gt_anomaly.int().cpu())
            pr_anomalys.append(image_anomaly_pred.cpu())
        else:
            gt_masks.append(gt_mask.int())
            pr_masks.append(pixel_anomaly_map)


            gt_anomalys.append(gt_anomaly.int())
            pr_anomalys.append(image_anomaly_pred)
            if args.radaptclip and k_shots == 0 and args.use_zero_rank_gate:
                rank_base_pr_anomalys.append(rank_base_image_pred)
                rank_pseudo_pr_anomalys.append(rank_pseudo_image_pred)

    # ====================== Evaluation ======================
    results_eval = dict(sample_ids=sample_ids, gt_masks=gt_masks, pr_masks=pr_masks, cls_names=cls_names, gt_anomalys=gt_anomalys, pr_anomalys=pr_anomalys, query_paths=query_paths)
    results_eval = {k: np.concatenate(v, axis=0) if k in ['cls_names', 'query_paths', 'sample_ids']  else torch.cat(v, dim=0) for k, v in results_eval.items()}

    if args.radaptclip and k_shots == 0 and args.use_zero_rank_gate and rank_base_pr_anomalys and rank_pseudo_pr_anomalys:
        rank_base_scores = torch.cat(rank_base_pr_anomalys, dim=0)
        rank_pseudo_scores = torch.cat(rank_pseudo_pr_anomalys, dim=0)
        results_eval['pr_anomalys'] = apply_zero_rank_gate(
            results_eval,
            rank_base_scores,
            rank_pseudo_scores,
            max_weight=args.zero_rank_gate_max_weight,
            min_corr=args.zero_rank_gate_min_corr,
            logger=logger,
        )

    # save results
    msg = {}
    for idx, cls_name in enumerate(tqdm(obj_list)):
        metric_results = evaluator.run(results_eval, cls_name, logger)
        msg['Name'] = msg.get('Name', [])
        msg['Name'].append(cls_name)
        avg_act = True if len(obj_list) > 1 and idx == len(obj_list) - 1 else False
        msg['Name'].append('Avg') if avg_act else None

        for metric in eval_metrics:
            metric_result = metric_results[metric] * 100

            msg[metric] = msg.get(metric, [])
            msg[metric].append(metric_result)

            if avg_act:
                metric_result_avg = sum(msg[metric]) / len(msg[metric])
                msg[metric].append(metric_result_avg)

    tab = tabulate(msg, headers='keys', tablefmt="pipe", floatfmt='.1f', numalign="center", stralign="center", )
    logger.info('\n' + tab)

    if args.save_prompt_weights:
        weight_file = f'{dataset_name}_{seed}seed_{k_shots}shot_prompt_weights.csv'
        save_prompt_weight_records(save_path, weight_file, prompt_weight_records)

    if args.save_risk_gates:
        gate_file = f'{dataset_name}_{seed}seed_{k_shots}shot_risk_gates.csv'
        save_risk_gate_records(save_path, gate_file, risk_gate_records)



if __name__ == '__main__':
    parser = argparse.ArgumentParser("AdaptCLIP", add_help=True)
    # paths
    parser.add_argument("--test_data_path", type=str, default="./data/visa", help="path to test dataset")
    parser.add_argument("--save_path", type=str, default='./results/', help='path to save results')
    parser.add_argument("--pretrained_model", type=str, default='ViT-L/14@336px', help="pre-trained model name")
    parser.add_argument("--checkpoint_path", type=str, default='./adaptclip_checkpoint/', help='path to checkpoint')
    # model
    parser.add_argument("--dataset", type=str, default='mvtec')
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24], help="features used")
    parser.add_argument("--batch_size", type=int, default=8, help="batch size")
    parser.add_argument("--num_workers", type=int, default=4, help="number of dataloader workers for test data")
    parser.add_argument("--image_size", type=int, default=518, help="image size")
    parser.add_argument("--n_ctx", type=int, default=12, help="zero shot")
    parser.add_argument("--seed", type=int, default=10, help="random seed")
    parser.add_argument("--sigma", type=int, default=4, help="zero shot")
    parser.add_argument("--k_shots", type=int, default=1, help="how many normal samples")
    parser.add_argument("--visual_learner", action="store_true", help="Enable visual adapter")
    parser.add_argument("--textual_learner", action="store_true", help="Enable textual adapter")
    parser.add_argument("--pq_learner", action="store_true", help="Enable prompt-query adapter")
    parser.add_argument("--eval_metrics", type=str, nargs="+", default=['I-AUROC', 'I-AP', 'I-F1max', 'P-AUROC', 'P-AP', 'P-F1max', 'P-AUPRO'], help='evaluation metrics')
    parser.add_argument("--fusion_type", type=str, default="average_mean", help='fusion type')
    parser.add_argument("--vl_reduction", type=int, default=4, help="the reduction number of visual learner")
    parser.add_argument("--pq_mid_dim", type=int, default=128, help="the number of the first hidden layer in pqadapter")
    parser.add_argument("--pq_context", action="store_true", help="Enable context feature")
    parser.add_argument("--radaptclip", action="store_true", help="Enable R-AdaptCLIP inference path")
    parser.add_argument("--structure_align", type=str, choices=["original", "soft_topk", "local_soft_topk", "prototype"], default=None, help="R-AdaptCLIP prompt-query alignment mode")
    parser.add_argument("--pseudo_structure_align", type=str, choices=["original", "soft_topk", "local_soft_topk", "prototype"], default=None, help="R-AdaptCLIP zero-shot pseudo prompt alignment mode")
    parser.add_argument("--align_topk", type=int, default=5, help="top-k patches for soft_topk alignment")
    parser.add_argument("--align_temperature", type=float, default=0.05, help="temperature for soft_topk alignment and alignment confidence")
    parser.add_argument("--align_window", type=int, default=2, help="local window radius for local_soft_topk alignment")
    parser.add_argument("--align_spatial_weight", type=float, default=0.0, help="spatial distance penalty for local_soft_topk alignment")
    parser.add_argument("--reliability_temperature", type=float, default=1.0, help="temperature for prompt reliability softmax")
    parser.add_argument("--pseudo_keep_ratio", type=float, default=0.3, help="low-anomaly patch ratio used for zero-shot pseudo prompt")
    parser.add_argument("--use_prompt_reliability", action=argparse.BooleanOptionalAction, default=None, help="Enable prompt reliability weighting")
    parser.add_argument("--use_pseudo_prompt", action=argparse.BooleanOptionalAction, default=None, help="Enable zero-shot pseudo normal prompt")
    parser.add_argument("--use_pseudo_pixel", action=argparse.BooleanOptionalAction, default=None, help="Let zero-shot pseudo prompt affect pixel maps")
    parser.add_argument("--use_uncertainty_fusion", action=argparse.BooleanOptionalAction, default=None, help="Enable uncertainty-aware fusion")
    parser.add_argument("--use_pixel_gate", action=argparse.BooleanOptionalAction, default=None, help="Gate R-AdaptCLIP pixel maps with baseline fallback")
    parser.add_argument("--use_pixel_fallback", action=argparse.BooleanOptionalAction, default=None, help="Use original PQ output as few-shot pixel fallback")
    parser.add_argument("--use_decoupled_image_pixel", action=argparse.BooleanOptionalAction, default=False, help="Use separate pixel-map maxima for few-shot image scoring while keeping the final pixel map gated")
    parser.add_argument("--pixel_gate_max_weight", type=float, default=0.1, help="maximum gated weight for R-AdaptCLIP pixel maps")
    parser.add_argument("--pixel_gate_min_confidence", type=float, default=0.05, help="minimum confidence before using R-AdaptCLIP pixel maps")
    parser.add_argument("--use_risk_calibrated_pseudo_pixel", action=argparse.BooleanOptionalAction, default=None, help="Adaptively gate zero-shot pseudo pixel maps by entropy, agreement, and predicted anomaly area")
    parser.add_argument("--risk_gate_base_weight", type=float, default=0.05, help="minimum pseudo-pixel gate weight after risk calibration")
    parser.add_argument("--risk_gate_max_weight", type=float, default=0.35, help="maximum pseudo-pixel gate weight after risk calibration")
    parser.add_argument("--risk_gate_min_confidence", type=float, default=0.05, help="minimum risk confidence before opening the pseudo-pixel gate")
    parser.add_argument("--risk_gate_area_target", type=float, default=0.25, help="expected upper ratio of high-anomaly pixels for pseudo-pixel risk calibration")
    parser.add_argument("--risk_gate_area_threshold", type=float, default=0.5, help="threshold used to estimate predicted high-anomaly pixel ratio")
    parser.add_argument("--image_gate_max_weight", type=float, default=0.35, help="maximum gated weight for R-AdaptCLIP few-shot image scores")
    parser.add_argument("--image_gate_min_confidence", type=float, default=0.05, help="minimum confidence before using R-AdaptCLIP few-shot image scores")
    parser.add_argument("--image_pixel_gate_max_weight", type=float, default=None, help="optional separate pixel-support gate ceiling used only for few-shot image scoring")
    parser.add_argument("--image_pixel_gate_min_confidence", type=float, default=None, help="optional separate pixel-support confidence floor used only for few-shot image scoring")
    parser.add_argument("--use_zero_rank_gate", action=argparse.BooleanOptionalAction, default=False, help="Enable class-level rank-consistency gate for zero-shot pseudo image scores")
    parser.add_argument("--use_zero_image_gate", action=argparse.BooleanOptionalAction, default=True, help="Enable per-sample confidence gate for zero-shot pseudo image scores")
    parser.add_argument("--zero_rank_gate_max_weight", type=float, default=0.5, help="maximum pseudo image score weight for zero-shot rank gate")
    parser.add_argument("--zero_rank_gate_min_corr", type=float, default=0.0, help="minimum base/pseudo rank correlation before zero-shot rank gate opens")
    # DSA-Gate (Domain-Shift-Aware Gate)
    parser.add_argument("--use_dsa_gate", action=argparse.BooleanOptionalAction, default=None, help="Enable domain-shift-aware adaptive fusion ceiling for zero-shot image scores")
    parser.add_argument("--dsa_gate_sharpness", type=float, default=5.0, help="sharpness of DSA-gate sigmoid mapping (higher = more conservative)")
    parser.add_argument("--dsa_gate_min_weight", type=float, default=0.05, help="minimum max_weight floor for DSA-gate (conservative floor)")
    parser.add_argument("--max_test_samples", type=int, default=0, help="balanced per-class test sample cap for quick smoke experiments")
    parser.add_argument("--save_prompt_weights", action="store_true", help="Save R-AdaptCLIP prompt reliability weights")
    parser.add_argument("--save_risk_gates", action="store_true", help="Save per-sample risk-calibrated pseudo-pixel gate diagnostics")
    parser.add_argument("--save_visuals", action="store_true", help="Save anomaly heatmap visualizations")
    parser.add_argument("--class_name", type=str, help="class name for a special dataset, for example, bottle in MVTec")
    # R-AdaptCLIP v2 innovations
    parser.add_argument("--use_sra", action="store_true", help="Enable Spectral Residual Analysis")
    parser.add_argument("--use_mcv", action="store_true", help="Enable Mutual Consistency Verification")
    parser.add_argument("--use_taf", action="store_true", help="Enable Temperature-Annealed Fusion")
    parser.add_argument("--use_meta_reliability", action="store_true", help="Enable Meta-Reliability (HRD+MCV)")
    parser.add_argument("--use_prompt_dropout", action="store_true", help="Drop low-reliability few-shot prompts before prompt fusion")
    parser.add_argument("--prompt_dropout_quantile", type=float, default=0.25, help="Reliability-score quantile below which prompts are dropped")
    parser.add_argument("--prompt_dropout_min_keep", type=int, default=1, help="Minimum number of prompts kept after reliability dropout")
    parser.add_argument("--prompt_keep_topk", type=int, default=0, help="If positive, keep exactly the top-k reliability prompts instead of using a quantile threshold")
    args = parser.parse_args()
    print(args)
    setup_seed(args.seed)
    test(args)
