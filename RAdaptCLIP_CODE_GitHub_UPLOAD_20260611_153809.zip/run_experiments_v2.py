#!/usr/bin/env python3
"""
R-AdaptCLIP v2.0: Comprehensive Experiment Suite
=================================================
Runs: baseline + R-AdaptCLIP + spectral/mcv/taf innovations on MVTec + VisA
"""
import subprocess, os, sys, json
from pathlib import Path

PYTHON = r"D:/work/anaconda/envs/py39_pytorch2.3.1/python.exe"
REPO = Path(r"E:/CILP/AdaptCLIP")
CKPT = "./adaptclip_checkpoints/12_4_128_train_on_visa_3adapters_batch8/epoch_15.pth"

BASE_ARGS = "--dataset mvtec --test_data_path ./dataset/mvtec --seed 10 --features_list 6 12 18 24 --image_size 518 --batch_size 4 --n_ctx 12 --vl_reduction 4 --pq_mid_dim 128 --visual_learner --textual_learner --pq_learner --pq_context --sigma 4"

# MVTec classes with real mask (only bottle has GT; others dummy-masked)
MVTE_CLASSES = ["bottle", "cable", "capsule", "carpet"]

# VisA classes we can test (quick subset)
VISA_CLASSES = ["candle", "capsules", "pcb1"]

EXPERIMENTS = [
    # (exp_name, shot, extra_args)
    ("baseline_0shot", 0, ""),
    ("radapt_v2_0shot", 0, "--radaptclip --structure_align soft_topk --align_topk 5 --use_pseudo_prompt --use_uncertainty_fusion"),
    ("radapt_v2_mcv_0shot", 0, "--radaptclip --structure_align soft_topk --align_topk 5 --use_pseudo_prompt --use_uncertainty_fusion --use_mcv --use_taf"),
    ("baseline_1shot", 1, ""),
    ("radapt_v2_1shot", 1, "--radaptclip --structure_align local_soft_topk --align_topk 5 --align_window 2 --use_prompt_reliability --use_uncertainty_fusion --use_pixel_gate"),
    ("radapt_v2_mcv_1shot", 1, "--radaptclip --structure_align local_soft_topk --align_topk 5 --align_window 2 --use_prompt_reliability --use_uncertainty_fusion --use_pixel_gate --use_meta_reliability --use_taf"),
    ("baseline_2shot", 2, ""),
    ("radapt_v2_2shot", 2, "--radaptclip --structure_align local_soft_topk --align_topk 5 --align_window 2 --use_prompt_reliability --use_uncertainty_fusion --use_pixel_gate"),
    ("radapt_v2_mcv_2shot", 2, "--radaptclip --structure_align local_soft_topk --align_topk 5 --align_window 2 --use_prompt_reliability --use_uncertainty_fusion --use_pixel_gate --use_meta_reliability --use_taf"),
]

VISA_EXPERIMENTS = [
    ("baseline_visa_0shot", 0, ""),
    ("radapt_v2_visa_0shot", 0, "--radaptclip --structure_align soft_topk --align_topk 5 --use_pseudo_prompt --use_uncertainty_fusion"),
    ("radapt_v2_mcv_visa_0shot", 0, "--radaptclip --structure_align soft_topk --align_topk 5 --use_pseudo_prompt --use_uncertainty_fusion --use_mcv --use_taf"),
    ("baseline_visa_1shot", 1, ""),
    ("radapt_v2_visa_1shot", 1, "--radaptclip --structure_align local_soft_topk --align_topk 5 --align_window 2 --use_prompt_reliability --use_uncertainty_fusion --use_pixel_gate"),
    ("radapt_v2_mcv_visa_1shot", 1, "--radaptclip --structure_align local_soft_topk --align_topk 5 --align_window 2 --use_prompt_reliability --use_uncertainty_fusion --use_pixel_gate --use_meta_reliability --use_taf"),
]

def parse_output(stdout_lines):
    """Parse test output to extract metric table."""
    results = {}
    for line in stdout_lines:
        line = line.strip()
        if '|' not in line or 'Name' in line or '---' in line:
            continue
        parts = [p.strip() for p in line.strip().strip('|').split('|')]
        if len(parts) >= 8:
            cls = parts[0]
            try:
                results[cls] = {
                    'I-AUROC': float(parts[1]),
                    'I-AP': float(parts[2]),
                    'I-F1max': float(parts[3]),
                    'P-AUROC': float(parts[4]),
                    'P-AP': float(parts[5]),
                    'P-F1max': float(parts[6]),
                    'P-AUPRO': float(parts[7]),
                }
            except (ValueError, IndexError):
                pass
    return results

def run_experiment(exp_name, k_shots, extra_args, classes, dataset="mvtec", data_dir="./dataset/mvtec"):
    """Run a single experiment and return results."""
    results = {}
    for cls_name in classes:
        save_dir = REPO / f"results/{exp_name}"
        save_dir.mkdir(parents=True, exist_ok=True)

        base = BASE_ARGS.replace("--dataset mvtec", f"--dataset {dataset}")
        base = base.replace("--test_data_path ./dataset/mvtec", f"--test_data_path {data_dir}")

        cmd = f'{PYTHON} test_radapt_v2.py {base} --k_shots {k_shots} {extra_args} --class_name {cls_name} --checkpoint_path {CKPT} --save_path {save_dir}'
        print(f"\n{'='*80}")
        print(f"RUN: {exp_name} / {cls_name} / {k_shots}-shot")
        print(f"CMD: {cmd}")
        print(f"{'='*80}")

        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = "0"

        try:
            proc = subprocess.run(cmd, shell=True, cwd=str(REPO), env=env,
                                capture_output=True, text=True, timeout=600)
        except subprocess.TimeoutExpired:
            print(f"  TIMEOUT for {cls_name}")
            continue

        # Parse results
        cls_results = parse_output(proc.stdout.split('\n'))
        if cls_name in cls_results:
            results[cls_name] = cls_results[cls_name]
            print(f"  OK: I-AUROC={cls_results[cls_name]['I-AUROC']:.1f}, P-AUROC={cls_results[cls_name]['P-AUROC']:.1f}")
        else:
            print(f"  WARN: Could not parse results for {cls_name}")
            # Print last 30 lines for debugging
            for line in proc.stdout.split('\n')[-30:]:
                if line.strip():
                    print(f"    {line.strip()[:120]}")

        if proc.returncode != 0 and proc.stderr:
            err_lines = [l for l in proc.stderr.split('\n') if 'Error' in l or 'Traceback' in l]
            if err_lines:
                print(f"  ERR: {err_lines[-1][:200]}")

    return results


def print_summary(all_results):
    """Print formatted summary table."""
    print("\n" + "="*120)
    print("FINAL RESULTS SUMMARY")
    print("="*120)
    header = f"{'Experiment':<35s} {'Class':<10s} {'Shot':<6s} {'I-AUROC':>8s} {'I-AP':>8s} {'P-AUROC':>8s} {'P-AP':>8s} {'P-F1max':>8s}"
    print(header)
    print("-"*120)

    for exp_name, data in all_results.items():
        for cls, metrics in data.items():
            if 'shot' in exp_name.lower():
                shot = exp_name.split('_')[1].replace('shot', '')
            else:
                shot = '-'
            print(f"{exp_name:<35s} {cls:<10s} {shot:<6s} "
                  f"{metrics.get('I-AUROC', 0):>8.1f} {metrics.get('I-AP', 0):>8.1f} "
                  f"{metrics.get('P-AUROC', 0):>8.1f} {metrics.get('P-AP', 0):>8.1f} "
                  f"{metrics.get('P-F1max', 0):>8.1f}")


def main():
    all_results = {}

    # Phase 1: MVTec Bottle (quick validation, 1 class)
    print("\n" + "="*80)
    print("PHASE 1: MVTec Bottle Quick Validation")
    print("="*80)
    for exp_name, shot, extra in EXPERIMENTS:
        if '0shot' in exp_name or '1shot' in exp_name:  # Run 0-shot and 1-shot first
            cls_results = run_experiment(exp_name, shot, extra, ["bottle"])
            all_results[exp_name] = cls_results

    print_summary(all_results)

    # Save results
    output_file = REPO / "results/experiment_results_v2.json"
    with open(output_file, 'w') as f:
        json.dump(all_results, f, indent=2, default=str)
    print(f"\nResults saved to: {output_file}")


if __name__ == "__main__":
    main()
