import copy
import multiprocessing

import numpy as np
import torch
from numba import jit
from scipy.ndimage import gaussian_filter
from skimage import measure
from sklearn.metrics import (auc, average_precision_score,
                             precision_recall_curve, roc_auc_score)
from torch.nn import functional as F


def func(th, amaps, binary_amaps, masks):
    print('start', th)
    binary_amaps[amaps <= th], binary_amaps[amaps > th] = 0, 1
    pro = []
    for binary_amap, mask in zip(binary_amaps, masks):
        for region in measure.regionprops(measure.label(mask)):
            tp_pixels = binary_amap[region.coords[:, 0], region.coords[:, 1]].sum()
            pro.append(tp_pixels / region.area)
    inverse_masks = 1 - masks
    fp_pixels = np.logical_and(inverse_masks, binary_amaps).sum()
    fpr = fp_pixels / inverse_masks.sum()
    print('end', th)
    return [np.array(pro).mean(), fpr, th]


class Evaluator(object):
    def __init__(self, metrics=[], pooling_ks=None, max_step_aupro=200, mp=False):
        if len(metrics) == 0:
            self.metrics = [
                'I-AUROC', 'I-AP', 'I-F1max',
                'P-AUROC', 'P-AP', 'P-F1max', 'P-AUPRO'
            ]
        else:
            self.metrics = metrics

        self.pooling_ks = pooling_ks
        self.max_step_aupro = max_step_aupro
        self.mp = mp

        self.eps = 1e-8
        self.beta = 1.0

        self.boundary = 1e-7

    def run(self, results, cls_name, logger=None):
        idxes = results['cls_names'] == cls_name
        gt_px = results['gt_masks'][idxes]
        if results['pr_masks'] is not None:
            pr_px = results['pr_masks'][idxes]

        gt_sp = results['gt_anomalys'][idxes]
        pr_sp = results['pr_anomalys'][idxes]
        pr_sp_max = pr_sp

        if len(gt_px.shape) == 4:
            gt_px = gt_px.squeeze(1)
        if len(pr_px.shape) == 4 and results['pr_masks'] is not None:
            pr_px = pr_px.squeeze(1)

        # normalization for pixel-level evaluations
        if results['pr_masks'] is not None:
            pr_px_norm = (pr_px - pr_px.min()) / (pr_px.max() - pr_px.min())

        '''
        if self.pooling_ks is not None:
            pr_px_pooling = F.avg_pool2d(torch.tensor(pr_px).unsqueeze(1), self.pooling_ks, stride=1).numpy().squeeze(1)
            pr_sp_max = pr_px_pooling.max(axis=(1, 2))
            pr_sp_mean = pr_px_pooling.mean(axis=(1, 2))
        else:
            pr_sp_max = pr_px.max(axis=(1, 2))
            pr_sp_mean = pr_px.mean(axis=(1, 2))
        '''

        metric_str = f'==> Metric Time for {cls_name:<15}: '
        metric_results = {}
        for metric in self.metrics:
            if metric.startswith('I-AUROC'):
                auroc_sp = roc_auc_score(gt_sp, pr_sp_max)
                metric_results[metric] = auroc_sp

            elif metric.startswith('P-AUROC'):

                auroc_px = roc_auc_score(gt_px.ravel(), pr_px.ravel())
                metric_results[metric] = auroc_px

            elif metric.startswith('P-AUPRO'):
                aupro_px = self.cal_pro_score(gt_px, pr_px, max_step=self.max_step_aupro, mp=self.mp)
                metric_results[metric] = aupro_px

            elif metric.startswith('I-AP'):
                ap_sp = average_precision_score(gt_sp, pr_sp_max)
                metric_results[metric] = ap_sp

            elif metric.startswith('P-AP'):

                ap_px = average_precision_score(gt_px.ravel(), pr_px.ravel())
                metric_results[metric] = ap_px

            elif metric.startswith('I-F1max'):
                precisions, recalls, thresholds = precision_recall_curve(gt_sp, pr_sp_max)
                f1_scores = (2 * precisions * recalls) / (precisions + recalls)
                best_f1_score = np.max(f1_scores[np.isfinite(f1_scores)])
                best_f1_score_index = np.argmax(f1_scores[np.isfinite(f1_scores)])
                best_threshold = thresholds[best_f1_score_index]
                metric_results[metric] = best_f1_score
            elif metric.startswith('P-F1max') or metric.startswith('P-IoU'):
                # F1_px equals Dice_px
                score_l, score_h, score_step = 0.0, 1.0, 0.05
                gt = gt_px.astype(np.bool_)
                metric_scores = []
                for score in np.arange(score_l, score_h + 1e-3, score_step):
                    pr = pr_px_norm > score
                    total_area_intersect = np.logical_and(gt, pr).sum(axis=(0, 1, 2))
                    total_area_union = np.logical_or(gt, pr).sum(axis=(0, 1, 2))
                    total_area_pred_label = pr.sum(axis=(0, 1, 2))
                    total_area_label = gt.sum(axis=(0, 1, 2))
                    if metric.startswith('P-F1max'):
                        precision = total_area_intersect / (total_area_pred_label + self.eps)
                        recall = total_area_intersect / (total_area_label + self.eps)
                        f1_px = (1 + self.beta ** 2) * precision * recall / (
                                    self.beta ** 2 * precision + recall + self.eps)
                        metric_scores.append(f1_px)
                    elif metric.startswith('P-Dice_max'):
                        dice_px = 2 * total_area_intersect / (total_area_pred_label + total_area_label + self.eps)
                        metric_scores.append(dice_px)
                    elif metric.startswith('P-Acc_max'):
                        acc_px = total_area_intersect / (total_area_label + self.eps)
                        metric_scores.append(acc_px)
                    elif metric.startswith('P-IoU'):
                        iou_px = total_area_intersect / (total_area_union + self.eps)
                        metric_scores.append(iou_px)
                    else:
                        raise f'invalid metric: {metric}'
                metric_results[metric] = np.array(metric_scores).max()
        return metric_results

    @staticmethod
    def cal_anomaly_map(ft_list, fs_list, out_size=[224, 224], uni_am=False, use_cos=True, amap_mode='add', gaussian_sigma=0, weights=None):
        bs = ft_list[0].shape[0]
        weights = weights if weights else [1] * len(ft_list)
        anomaly_map = np.ones([bs] + out_size) if amap_mode == 'mul' else np.zeros([bs] + out_size)
        a_map_list = []
        if uni_am:
            size = (ft_list[0].shape[2], ft_list[0].shape[3])
            for i in range(len(ft_list)):
                ft_list[i] = F.interpolate(F.normalize(ft_list[i], p=2), size=size, mode='bilinear', align_corners=True)
                fs_list[i] = F.interpolate(F.normalize(fs_list[i], p=2), size=size, mode='bilinear', align_corners=True)
            ft_map, fs_map = torch.cat(ft_list, dim=1), torch.cat(fs_list, dim=1)
            if use_cos:
                a_map = 1 - F.cosine_similarity(ft_map, fs_map, dim=1)
                a_map = a_map.unsqueeze(dim=1)
            else:
                a_map = torch.sqrt(torch.sum((ft_map - fs_map) ** 2, dim=1, keepdim=True))
            a_map = F.interpolate(a_map, size=out_size, mode='bilinear', align_corners=True)
            a_map = a_map.squeeze(dim=1).cpu().detach().numpy()
            anomaly_map = a_map
            a_map_list.append(a_map)
        else:
            for i in range(len(ft_list)):
                ft = ft_list[i]
                fs = fs_list[i]
                if use_cos:
                    a_map = 1 - F.cosine_similarity(ft, fs, dim=1)
                    a_map = a_map.unsqueeze(dim=1)
                else:
                    a_map = torch.sqrt(torch.sum((ft - fs) ** 2, dim=1, keepdim=True))
                a_map = F.interpolate(a_map, size=out_size, mode='bilinear', align_corners=True)
                a_map = a_map.squeeze(dim=1)
                a_map = a_map.cpu().detach().numpy()
                a_map_list.append(a_map)
                if amap_mode == 'add':
                    anomaly_map += a_map * weights[i]
                else:
                    anomaly_map *= a_map
            if amap_mode == 'add':
                anomaly_map /= (len(ft_list) * sum(weights))
        if gaussian_sigma > 0:
            for idx in range(anomaly_map.shape[0]):
                anomaly_map[idx] = gaussian_filter(anomaly_map[idx], sigma=gaussian_sigma)
        return anomaly_map, a_map_list

    @staticmethod
    def cal_pro_thr(results, th, amaps, masks):
        binary_amaps = np.zeros_like(amaps, dtype=np.bool_)
        binary_amaps[amaps <= th], binary_amaps[amaps > th] = 0, 1
        pro = []
        for binary_amap, mask in zip(binary_amaps, masks):
            for region in measure.regionprops(measure.label(mask)):
                tp_pixels = binary_amap[region.coords[:, 0], region.coords[:, 1]].sum()
                pro.append(tp_pixels / region.area)
        inverse_masks = 1 - masks
        fp_pixels = np.logical_and(inverse_masks, binary_amaps).sum()
        fpr = fp_pixels / inverse_masks.sum()
        results.append([np.array(pro).mean(), fpr, th])
        # return [np.array(pro).mean(), fpr, th]

    @staticmethod
    def cal_pro_score(masks, amaps, max_step=200, expect_fpr=0.3, mp=False):
        # ref: https://github.com/gudovskiy/cflow-ad/blob/master/train.py
        min_th, max_th = amaps.min(), amaps.max()
        delta = (max_th - min_th) / max_step
        pros, fprs, ths = [], [], []
        if mp:
            # enable in the main process, i.e., __main__
            # pool = multiprocessing.Pool(processes=int(multiprocessing.cpu_count() * 0.25))
            # jobs = []
            # for th in np.arange(min_th, max_th, delta):
            #     job = pool.apply_async(Evaluator.cal_pro_thr, args=(th, amaps, masks, ))
            #     jobs.append(job)
            # pool.close()
            # pool.join()
            # results = []
            # for job in jobs:
            #     results.append(job.get())
            #     print(results[-1])

            # multiprocessing.Process has no `get` function
            results = multiprocessing.Manager().list()
            jobs = []
            for th in np.arange(min_th, max_th, delta):
                job = multiprocessing.Process(target=Evaluator.cal_pro_thr, args=(results, th, amaps, masks,))
                job.start()
                jobs.append(job)
            for job in jobs:
                job.join()
            results = list(results)
            results.sort(key=lambda x: float(x[2]))
            for result in results:
                pros.append(result[0])
                fprs.append(result[1])
                ths.append(result[2])
        else:
            # ref: https://github.com/gudovskiy/cflow-ad/blob/master/train.py
            binary_amaps = np.zeros_like(amaps, dtype=np.bool_)
            for th in np.arange(min_th, max_th, delta):
                binary_amaps[amaps <= th], binary_amaps[amaps > th] = 0, 1
                pro = []
                for binary_amap, mask in zip(binary_amaps, masks):
                    for region in measure.regionprops(measure.label(mask)):
                        tp_pixels = binary_amap[region.coords[:, 0], region.coords[:, 1]].sum()
                        pro.append(tp_pixels / region.area)
                inverse_masks = 1 - masks
                fp_pixels = np.logical_and(inverse_masks, binary_amaps).sum()
                fpr = fp_pixels / inverse_masks.sum()
                pros.append(np.array(pro).mean())
                fprs.append(fpr)
                ths.append(th)

        pros, fprs, ths = np.array(pros), np.array(fprs), np.array(ths)
        idxes = fprs < expect_fpr
        fprs = fprs[idxes]
        fprs = (fprs - fprs.min()) / (fprs.max() - fprs.min())
        pro_auc = auc(fprs, pros[idxes])

        return pro_auc
