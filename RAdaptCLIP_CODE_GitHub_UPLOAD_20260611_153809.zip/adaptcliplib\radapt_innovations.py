"""
R-AdaptCLIP Innovations: Spectral Residual Analysis & Mutual Consistency Verification
======================================================================================

Novel components for next-level anomaly detection:
1. SRA: Spectral Residual Analysis - frequency-domain anomaly decomposition
2. MCV: Mutual Consistency Verification - cross-prompt meta-reliability
3. TAF: Temperature-Annealed Fusion - adaptive prompt weighting
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


# ==============================================================================
# 1. SPECTRAL RESIDUAL ANALYSIS (SRA)
# ==============================================================================
class SpectralResidualAnalyzer(nn.Module):
    """
    Decompose residual features into frequency bands using 2D FFT.
    Each frequency band captures different anomaly types:
    - Low freq: structural/geometric anomalies (dents, missing parts)
    - Mid freq: texture anomalies (scratches, contamination)
    - High freq: fine-grained anomalies (edge defects, noise patterns)

    Key insight: Real anomalies often concentrate energy in specific frequency
    bands, while noise is spread across all bands. By learning band-specific
    anomaly scores, we get better separation.
    """
    def __init__(self, input_dim=768, num_bands=3, mid_dim=64):
        super().__init__()
        self.num_bands = num_bands
        self.input_dim = input_dim

        # Per-band anomaly scoring heads (lightweight 1x1 convs)
        self.band_scorers = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(input_dim, mid_dim, 1, bias=False),
                nn.BatchNorm2d(mid_dim),
                nn.ReLU(inplace=True),
                nn.Conv2d(mid_dim, 1, 1, bias=False),
            ) for _ in range(num_bands)
        ])

        # Learnable band importance weights
        self.band_weights = nn.Parameter(torch.ones(num_bands) / num_bands)

        # Band boundary frequencies (normalized 0 to 0.5)
        # Low: 0 to 0.1, Mid: 0.1 to 0.25, High: 0.25 to 0.5
        self.register_buffer('band_boundaries', torch.tensor([0.0, 0.1, 0.25, 0.5]))

    def _frequency_decompose(self, feature_map):
        """
        Decompose 2D feature map into frequency bands using FFT.
        Input: (B, C, H, W)
        Returns: list of (B, C, H, W) tensors, one per band
        """
        B, C, H, W = feature_map.shape

        # 2D FFT
        fft = torch.fft.fft2(feature_map.float(), norm='ortho')
        fft_shifted = torch.fft.fftshift(fft, dim=(-2, -1))

        # Create frequency grid
        fy = torch.fft.fftfreq(H, d=1.0).to(feature_map.device)
        fx = torch.fft.fftfreq(W, d=1.0).to(feature_map.device)
        fy, fx = torch.meshgrid(torch.abs(fy), torch.abs(fx), indexing='ij')
        freq_grid = torch.sqrt(fy**2 + fx**2)  # (H, W)

        band_features = []
        for b in range(self.num_bands):
            low = self.band_boundaries[b].item()
            high = self.band_boundaries[b + 1].item()
            mask = ((freq_grid >= low) & (freq_grid < high)).float()
            mask = mask.unsqueeze(0).unsqueeze(0)  # (1, 1, H, W)

            # Filter in frequency domain
            band_fft = fft_shifted * mask
            # Inverse FFT
            band_spatial = torch.fft.ifft2(
                torch.fft.ifftshift(band_fft, dim=(-2, -1)),
                norm='ortho'
            ).real

            band_features.append(band_spatial)

        return band_features

    def forward(self, residual_features):
        """
        Args:
            residual_features: (B, C, H, W) tensor of query-prompt residuals
        Returns:
            band_scores: (B, num_bands, H, W) per-band anomaly scores
            combined_score: (B, 1, H, W) weighted combination
            band_weights_normalized: (num_bands,) learned importance
        """
        band_features = self._frequency_decompose(residual_features)

        band_scores = []
        for b, feat in enumerate(band_features):
            score = self.band_scorers[b](feat)  # (B, 1, H, W)
            band_scores.append(score)

        band_scores = torch.cat(band_scores, dim=1)  # (B, num_bands, H, W)

        # Normalize band weights
        band_weights_norm = F.softmax(self.band_weights, dim=0)

        # Weighted combination
        combined_score = (band_scores * band_weights_norm[None, :, None, None]).sum(dim=1, keepdim=True)

        return band_scores, combined_score, band_weights_norm


# ==============================================================================
# 2. MUTUAL CONSISTENCY VERIFICATION (MCV)
# ==============================================================================
def mutual_consistency_scores(promptwise_global_logits, promptwise_local_scores,
                               promptwise_align_scores, temperature=1.0):
    """
    Cross-validate each prompt against the consensus of all OTHER prompts.

    Key insight: A reliable prompt should produce anomaly predictions that
    agree with the consensus of other prompts. Large deviation indicates
    either the prompt is low-quality OR it captures a unique anomaly view.
    We use this as a meta-reliability signal.

    Args:
        promptwise_global_logits: list of (B, S, 2) per-layer global logits
        promptwise_local_scores: list of (B, S, 2, H, W) per-layer local scores
        promptwise_align_scores: list of (B, S, 1, H, W) per-layer align scores

    Returns:
        consistency_scores: (B, S) mutual consistency per prompt (higher=more reliable)
        consensus_map: (B, H, W) leave-one-out consensus anomaly map
    """
    # Stack prompts: (B, S, ...)
    local_stack = torch.stack([x[:, :, 1] for x in promptwise_local_scores], dim=0).mean(dim=0)  # (B, S, H, W)
    global_stack = torch.stack([x.softmax(-1)[:, :, 1] for x in promptwise_global_logits], dim=0).mean(dim=0)  # (B, S)

    B, S, H, W = local_stack.shape

    if S <= 1:
        return torch.ones(B, S, device=local_stack.device), local_stack[:, 0]

    consistency_scores = []
    for j in range(S):
        # Leave-one-out: consensus from all prompts except j
        mask = torch.ones(S, device=local_stack.device)
        mask[j] = 0
        mask = mask / (S - 1)

        # LOO consensus
        loo_global = (global_stack * mask[None, :]).sum(dim=1)
        loo_local = (local_stack * mask[None, :, None, None]).sum(dim=1)

        # Agreement between prompt j and LOO consensus
        global_agree = 1.0 - (global_stack[:, j] - loo_global).abs()
        local_agree = 1.0 - (local_stack[:, j] - loo_local).abs().flatten(1).mean(dim=1)

        # Combined consistency
        consistency = 0.4 * global_agree + 0.6 * local_agree
        consistency_scores.append(consistency)

    consistency_scores = torch.stack(consistency_scores, dim=1)  # (B, S)

    # Full consensus map
    consensus_map = local_stack.mean(dim=1)  # (B, H, W)

    return consistency_scores, consensus_map


# ==============================================================================
# 3. TEMPERATURE-ANNEALED FUSION (TAF)
# ==============================================================================
def temperature_annealed_fusion(prompt_scores, prompt_maps, prompt_weights,
                                 base_temperature=1.0, min_temperature=0.1,
                                 max_temperature=5.0):
    """
    Dynamically adjust the fusion temperature based on prompt agreement.

    When prompts strongly agree (low weight entropy) → higher temperature →
    more uniform averaging (don't over-trust any single prompt).

    When prompts strongly disagree (high weight entropy) → lower temperature →
    peakier distribution (trust the most reliable prompt more).

    This creates a principled, adaptive fusion mechanism.

    Args:
        prompt_scores: (B, S) or (B, S, H, W) per-prompt predictions
        prompt_weights: (B, S) reliability weights
        base_temperature: float, starting temperature
        min_temperature: float, minimum annealed temperature
        max_temperature: float, maximum annealed temperature

    Returns:
        fused_output: weighted combination with annealed temperature
        annealed_weights: (B, S) the actual weights used after annealing
    """
    B, S = prompt_weights.shape[:2]

    if S <= 1:
        return prompt_scores[:, 0], prompt_weights

    # Compute weight entropy as agreement measure
    eps = 1e-8
    safe_weights = prompt_weights.clamp(min=eps)
    weight_entropy = -(safe_weights * torch.log(safe_weights)).sum(dim=1) / np.log(S)

    # Map entropy to temperature: high entropy (disagreement) → low temp (peaky)
    # low entropy (agreement) → high temp (smooth)
    normalized_entropy = weight_entropy.clamp(0.0, 1.0)
    annealed_temp = max_temperature - (max_temperature - min_temperature) * normalized_entropy
    annealed_temp = annealed_temp.clamp(min_temperature, max_temperature)

    # Apply annealed temperature
    annealed_weights = F.softmax(
        torch.log(safe_weights) / annealed_temp[:, None],
        dim=1
    )

    # Fuse
    if prompt_scores.dim() == 4:  # Spatial
        fused = (prompt_scores * annealed_weights[:, :, None, None]).sum(dim=1)
    else:  # Scalar
        fused = (prompt_scores * annealed_weights).sum(dim=1)

    return fused, annealed_weights


# ==============================================================================
# 4. META-RELIABILITY FUSION: Combine HRD + MCV signals
# ==============================================================================
def compute_meta_reliability(query_feats, prompt_feats, local_maps, align_distances,
                              promptwise_global_logits, promptwise_local_scores,
                              promptwise_align_scores,
                              align_temperature=0.05, reliability_temperature=1.0):
    """
    Meta-reliability: combines primary reliability signals (HRD) with
    mutual consistency verification (MCV) for robust prompt weighting.

    The fusion is: meta_score = 0.7 * hrd_score + 0.3 * mcv_score

    This provides both direct prompt quality assessment AND cross-prompt
    validation, making the system robust to diverse failure modes.
    """
    from test import binary_entropy, normalize_prompt_scores

    B = query_feats.shape[0]

    # 1. Primary HRD reliability
    query_norm = F.normalize(query_feats, dim=-1)
    prompt_norm = F.normalize(prompt_feats, dim=-1)
    semantic = (F.cosine_similarity(query_norm.unsqueeze(1), prompt_norm, dim=-1) + 1.0) / 2.0

    align_tau = max(float(align_temperature), 1e-6)
    align_conf = torch.exp(-align_distances / align_tau)

    entropy_conf = 1.0 - binary_entropy(local_maps).flatten(2).mean(dim=-1)

    hrd_scores = 0.5 * semantic + 0.35 * align_conf + 0.15 * entropy_conf

    # 2. MCV reliability
    mcv_scores, consensus_map = mutual_consistency_scores(
        promptwise_global_logits, promptwise_local_scores, promptwise_align_scores
    )

    # 3. Meta fusion
    meta_scores = 0.7 * hrd_scores + 0.3 * mcv_scores

    meta_weights = normalize_prompt_scores(meta_scores, temperature=reliability_temperature)

    return meta_weights, meta_scores, mcv_scores, consensus_map
