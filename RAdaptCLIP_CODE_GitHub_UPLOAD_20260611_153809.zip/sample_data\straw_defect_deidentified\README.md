# De-identified Straw Defect Samples

This folder contains three de-identified straw defect samples used only for qualitative visualization in the IJSAEM manuscript.

- `images/test/`: input straw images.
- `masks/test/`: corresponding binary defect masks.

The complete internal straw defect dataset is not included because it contains production images. These examples are intended to show the data format and the qualitative inspection case, not to support full quantitative claims.
