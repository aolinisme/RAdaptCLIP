# R-AdaptCLIP

Reliability-aware AdaptCLIP extensions for low-cost visual anomaly inspection in small manufacturing enterprises.

This repository contains the cleaned code snapshot used for the IJSAEM manuscript:

**R-AdaptCLIP: A Low-Cost Reliability-Aware Visual Inspection Framework for Small Manufacturing Enterprises**

The release focuses on reproducibility under a budget hardware setting: a single RTX 3070 GPU with 8 GB memory. It includes source code, RTX 3070 friendly scripts, selected trace logs, de-identified straw defect samples, and qualitative straw inspection visualizations.

## What is Included

- Core AdaptCLIP/R-AdaptCLIP code: `adaptcliplib/`, `dataset/`, `metrics/`, `tools/`, `test.py`, `train.py`.
- RTX 3070 helper scripts: `run_rtx3070_lowrisk.py`, `run_xiguan_risk_fast.py`.
- De-identified straw defect case samples: `sample_data/straw_defect_deidentified/`.
- Traceable straw risk-fusion logs: `paper_artifacts/logs/`.
- Qualitative straw visualization panel: `visualizations/fig_straw_case_visualization.*`.

## What is Not Included

- Full MVTec, VisA, Kvasir, or internal straw datasets.
- Full experiment result directories.
- AdaptCLIP checkpoints or CLIP model weights.
- IDE folders, caches, and temporary build outputs.

These exclusions keep the repository light and avoid publishing internal production data.

## Recommended Environment

The experiments in the manuscript were run with:

- GPU: RTX 3070 Laptop GPU, 8 GB VRAM
- Python interpreter used locally: `D:/work/anaconda/envs/py39_pytorch2.3.1/python.exe`
- Image size: `518`
- Feature layers: `6 12 18 24`
- Batch size: start from `4`; use `2` if memory is tight

Install dependencies from:

```bash
pip install -r requirements.txt
```

You also need the original AdaptCLIP checkpoints. Place them under `adaptclip_checkpoints/` using the same layout as the original AdaptCLIP project.

## RTX 3070 Straw Case Smoke Test

Baseline zero-shot straw risk run:

```bash
python test.py \
  --test_data_path ./dataset/xiguan_yolo \
  --dataset xiguan_yolo \
  --checkpoint_path ./adaptclip_checkpoints/12_4_128_train_on_visa_3adapters_batch8/epoch_15.pth \
  --class_name xiguan \
  --k_shots 0 \
  --batch_size 4 \
  --num_workers 0 \
  --image_size 518 \
  --features_list 6 12 18 24 \
  --n_ctx 12 \
  --sigma 4 \
  --visual_learner --textual_learner --pq_learner --pq_context \
  --eval_metrics P-AUROC P-AP P-F1max
```

Risk-balanced R-AdaptCLIP zero-shot straw run:

```bash
python test.py \
  --test_data_path ./dataset/xiguan_yolo \
  --dataset xiguan_yolo \
  --checkpoint_path ./adaptclip_checkpoints/12_4_128_train_on_visa_3adapters_batch8/epoch_15.pth \
  --class_name xiguan \
  --k_shots 0 \
  --batch_size 4 \
  --num_workers 0 \
  --image_size 518 \
  --features_list 6 12 18 24 \
  --n_ctx 12 \
  --sigma 4 \
  --visual_learner --textual_learner --pq_learner --pq_context \
  --eval_metrics P-AUROC P-AP P-F1max \
  --radaptclip \
  --structure_align soft_topk \
  --pseudo_structure_align prototype \
  --align_topk 5 \
  --use_pseudo_prompt \
  --use_pseudo_pixel \
  --use_uncertainty_fusion \
  --use_pixel_gate \
  --no-use_zero_rank_gate \
  --use_risk_calibrated_pseudo_pixel \
  --risk_gate_base_weight 0.05 \
  --risk_gate_max_weight 0.35 \
  --risk_gate_area_target 0.25 \
  --save_risk_gates
```

For visualization-only smoke tests, add:

```bash
--max_test_samples 3 --save_visuals
```

## Traceable Straw Results

The manuscript uses traceable straw risk-fusion logs:

- AdaptCLIP baseline: P-AUROC 92.5, P-AP 52.4, P-F1max 60.0
- Fixed gate 0.35: P-AUROC 92.1, P-AP 54.8, P-F1max 60.0
- Risk-balanced: P-AUROC 92.3, P-AP 53.8, P-F1max 60.4
- Risk-recall: P-AUROC 92.2, P-AP 54.3, P-F1max 60.3

See `paper_artifacts/logs/` for the copied log files and summaries.

## Data Availability

The files under `sample_data/straw_defect_deidentified/` are small de-identified examples for qualitative inspection only. The complete internal straw defect dataset contains production images and is not published in this repository.

## Citation

If you use this repository, please cite the associated manuscript once published.
