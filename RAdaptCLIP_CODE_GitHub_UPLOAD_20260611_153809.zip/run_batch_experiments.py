#!/usr/bin/env python3
"""
Batch experiment runner: R-AdaptCLIP v2 on multiple datasets.
Cross-domain protocol: train on VisA -> test on MVTec (4 classes)
                       train on MVTec -> test on VisA (harder cross-domain)
"""
import subprocess, os, sys, json, time
from pathlib import Path

PYTHON = r"D:/work/anaconda/envs/py39_pytorch2.3.1/python.exe"
REPO = Path(r"E:/CILP/AdaptCLIP")

# Checkpoints
CKPT_MVTEC = "./adaptclip_checkpoints/12_4_128_train_on_mvtec_3adapters_batch8/epoch_15.pth"
CKPT_VISA = "./adaptclip_checkpoints/12_4_128_train_on_visa_3adapters_batch8/epoch_15.pth"

BASE_ARGS = "--seed 10 --features_list 6 12 18 24 --image_size 518 --batch_size 8 --n_ctx 12 --vl_reduction 4 --pq_mid_dim 128 --visual_learner --textual_learner --pq_learner --pq_context --sigma 4"

# ============================================================
# Experiment definitions
# ============================================================
EXPERIMENTS = [
    # === Phase 1: VisA checkpoint -> MVTec (4 classes, bottle has real mask) ===
    # 0-shot
    ("m_baseline_0s", "mvtec", "./dataset/mvtec", CKPT_VISA, 0, "bottle cable capsule carpet", ""),
    ("m_radapt_0s", "mvtec", "./dataset/mvtec", CKPT_VISA, 0, "bottle cable capsule carpet",
     "--radaptclip --structure_align soft_topk --align_topk 5 --use_pseudo_prompt --use_uncertainty_fusion --use_pixel_gate --pixel_gate_max_weight 0.1"),
    # 1-shot
    ("m_baseline_1s", "mvtec", "./dataset/mvtec", CKPT_VISA, 1, "bottle cable capsule carpet", ""),
    ("m_radapt_1s", "mvtec", "./dataset/mvtec", CKPT_VISA, 1, "bottle cable capsule carpet",
     "--radaptclip --structure_align local_soft_topk --align_topk 5 --align_window 2 --use_prompt_reliability --use_uncertainty_fusion --use_pixel_gate --pixel_gate_max_weight 0.1 --use_meta_reliability --use_taf"),

    # === Phase 2: MVTec checkpoint -> VisA (3 harder classes, true cross-domain) ===
    # 0-shot
    ("v_baseline_0s", "visa", "./dataset/visa", CKPT_MVTEC, 0, "candle capsules pcb1", ""),
    ("v_radapt_0s", "visa", "./dataset/visa", CKPT_MVTEC, 0, "candle capsules pcb1",
     "--radaptclip --structure_align soft_topk --align_topk 5 --use_pseudo_prompt --use_uncertainty_fusion --use_pixel_gate --pixel_gate_max_weight 0.1"),
    # 1-shot
    ("v_baseline_1s", "visa", "./dataset/visa", CKPT_MVTEC, 1, "candle capsules pcb1", ""),
    ("v_radapt_1s", "visa", "./dataset/visa", CKPT_MVTEC, 1, "candle capsules pcb1",
     "--radaptclip --structure_align local_soft_topk --align_topk 5 --align_window 2 --use_prompt_reliability --use_uncertainty_fusion --use_pixel_gate --pixel_gate_max_weight 0.1 --use_meta_reliability --use_taf"),
]


def parse_results(stdout_text):
    """Parse tabulate output to extract per-class metrics."""
    results = {}
    for line in stdout_text.split('\n'):
        line = line.strip()
        if '|' not in line or 'Name' in line or '---' in line or ':' in line:
            continue
        parts = [p.strip() for p in line.strip('|').split('|')]
        if len(parts) >= 8:
            cls = parts[0]
            try:
                results[cls] = {
                    'I-AUROC': float(parts[1]), 'I-AP': float(parts[2]),
                    'I-F1max': float(parts[3]), 'P-AUROC': float(parts[4]),
                    'P-AP': float(parts[5]), 'P-F1max': float(parts[6]),
                    'P-AUPRO': float(parts[7]),
                }
            except (ValueError, IndexError):
                pass
    return results


def run_one(exp_name, dataset, data_dir, ckpt, k_shots, classes_str, extra_args):
    """Run a single experiment and return results."""
    save_dir = REPO / f"results/batch_{exp_name}"
    save_dir.mkdir(parents=True, exist_ok=True)

    cmd = (f'{PYTHON} test.py --dataset {dataset} --test_data_path {data_dir} '
           f'--checkpoint_path {ckpt} {BASE_ARGS} --k_shots {k_shots} '
           f'--save_path {save_dir} --fusion_type average_mean {extra_args}')

    print(f"\n{'='*80}")
    print(f"RUN: {exp_name} | {dataset} | {k_shots}-shot | classes={classes_str}")
    print(f"{'='*80}")

    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "0"

    start = time.time()
    try:
        proc = subprocess.run(cmd, shell=True, cwd=str(REPO), env=env,
                            capture_output=True, text=True, timeout=600)
        elapsed = time.time() - start
    except subprocess.TimeoutExpired:
        print(f"  TIMEOUT after 600s")
        return {}

    results = parse_results(proc.stdout)
    if results:
        print(f"  OK ({elapsed:.0f}s):")
        for cls, metrics in results.items():
            print(f"    {cls:15s} I-AUROC={metrics['I-AUROC']:5.1f}  I-AP={metrics['I-AP']:5.1f}  P-AUROC={metrics['P-AUROC']:5.1f}  P-AP={metrics['P-AP']:5.1f}  P-F1={metrics['P-F1max']:5.1f}")
    else:
        print(f"  WARN: Could not parse results ({elapsed:.0f}s)")
        # Print last relevant lines for debugging
        for line in proc.stdout.split('\n')[-20:]:
            if line.strip():
                print(f"    {line.strip()[:150]}")
        if proc.returncode != 0 and proc.stderr:
            err_lines = [l for l in proc.stderr.split('\n') if 'Error' in l or 'Traceback' in l]
            for l in err_lines[-3:]:
                print(f"  ERR: {l[:200]}")

    return results


def main():
    all_results = {}
    print("=" * 80)
    print("R-AdaptCLIP v2: Batch Cross-Domain Experiments")
    print(f"Total experiments: {len(EXPERIMENTS)}")
    print("=" * 80)

    for i, (exp_name, dataset, data_dir, ckpt, k_shots, classes_str, extra_args) in enumerate(EXPERIMENTS):
        print(f"\n[{i+1}/{len(EXPERIMENTS)}] {exp_name}")
        results = run_one(exp_name, dataset, data_dir, ckpt, k_shots, classes_str, extra_args)
        if results:
            all_results[exp_name] = {'dataset': dataset, 'shots': k_shots, 'results': results}

    # ============================================================
    # Summary
    # ============================================================
    print("\n" + "=" * 120)
    print("FINAL SUMMARY: R-AdaptCLIP v2 Cross-Domain Results")
    print("=" * 120)
    hdr = f"{'Experiment':<25s} {'Class':<12s} {'Shot':<6s} {'I-AUROC':>8s} {'I-AP':>8s} {'P-AUROC':>8s} {'P-AP':>8s} {'P-F1':>8s}"
    print(hdr)
    print("-" * 120)

    for exp_name, exp_data in all_results.items():
        ds = exp_data['dataset']
        shot = exp_data['shots']
        for cls, metrics in exp_data['results'].items():
            print(f"{exp_name:<25s} {cls:<12s} {str(shot):<6s} "
                  f"{metrics['I-AUROC']:>8.1f} {metrics['I-AP']:>8.1f} "
                  f"{metrics['P-AUROC']:>8.1f} {metrics['P-AP']:>8.1f} "
                  f"{metrics['P-F1max']:>8.1f}")

    # Save to JSON
    out_file = REPO / "results/batch_results_v2.json"
    with open(out_file, 'w') as f:
        json.dump(all_results, f, indent=2, default=str)
    print(f"\nResults saved: {out_file}")


if __name__ == "__main__":
    main()
