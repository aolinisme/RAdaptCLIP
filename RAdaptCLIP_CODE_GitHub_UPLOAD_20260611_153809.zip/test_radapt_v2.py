#!/usr/bin/env python3
"""
R-AdaptCLIP v2.0: Spectral-Aware & Meta-Consistent Anomaly Detection
=====================================================================

Innovations:
1. SRA: Spectral Residual Analysis - frequency-domain anomaly decomposition
2. MCV: Mutual Consistency Verification - cross-prompt meta-reliability
3. TAF: Temperature-Annealed Fusion - adaptive prompt weighting
4. Meta-Reliability: HRD + MCV combined scoring

Run: python test_radapt_v2.py --test_data_path ./dataset/mvtec --k_shots 0 --radaptclip ...
"""

import argparse, csv, os, random, sys
from collections import defaultdict

import numpy as np
import torch
import torch.nn.functional as F
from scipy.ndimage import gaussian_filter
from tabulate import tabulate
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import adaptcliplib
from adaptcliplib import PQAdapter, TextualAdapter, VisualAdapter, fusion_fun
from adaptcliplib.radapt_innovations import (
    SpectralResidualAnalyzer,
    mutual_consistency_scores,
    temperature_annealed_fusion,
    compute_meta_reliability,
)
from dataset import Dataset, PromptDataset
from tools import Evaluator, get_logger, get_transform, setup_seed, visualizer


def binary_entropy(prob, eps=1e-6):
    prob = prob.clamp(min=eps, max=1.0 - eps)
    return -(prob * torch.log(prob) + (1.0 - prob) * torch.log(1.0 - prob)) / np.log(2.0)


def normalize_prompt_scores(scores, temperature=1.0):
    temperature = max(float(temperature), 1e-6)
    finite_rows = torch.isfinite(scores).all(dim=1)
    safe_scores = torch.nan_to_num(scores, nan=0.0, posinf=0.0, neginf=0.0)
    weights = torch.softmax(safe_scores / temperature, dim=1)
    if not finite_rows.all():
        uniform = torch.full_like(weights, 1.0 / weights.shape[1])
        weights = torch.where(finite_rows[:, None], weights, uniform)
    return weights


def compute_prompt_reliability(query_feats, prompt_feats, local_maps, align_distances,
                               align_temperature=0.05, reliability_temperature=1.0):
    query_norm = F.normalize(query_feats, dim=-1)
    prompt_norm = F.normalize(prompt_feats, dim=-1)
    semantic = (F.cosine_similarity(query_norm.unsqueeze(1), prompt_norm, dim=-1) + 1.0) / 2.0
    align_tau = max(float(align_temperature), 1e-6)
    align_conf = torch.exp(-align_distances / align_tau)
    entropy_conf = 1.0 - binary_entropy(local_maps).flatten(2).mean(dim=-1)
    scores = 0.5 * semantic + 0.35 * align_conf + 0.15 * entropy_conf
    weights = normalize_prompt_scores(scores, temperature=reliability_temperature)
    return weights, scores


def collapse_promptwise_outputs(global_logits, local_scores, align_scores, align_distances):
    prompt_local_maps = torch.stack([x[:, :, 1] for x in local_scores], dim=0).mean(dim=0)
    prompt_global_scores = torch.stack([x.softmax(-1)[:, :, 1] for x in global_logits], dim=0).mean(dim=0)
    prompt_align_maps = fusion_fun([x[:, :, 0] for x in align_scores], fusion_type='harmonic_mean')
    prompt_align_distances = torch.stack(align_distances, dim=0).mean(dim=0)
    return prompt_global_scores, prompt_local_maps, prompt_align_maps, prompt_align_distances


def collapse_standard_pq_outputs(global_logits, local_scores, align_scores):
    local_pq_map = torch.concat([x[:, 1].unsqueeze(1) for x in local_scores], dim=1).mean(dim=1).detach()
    align_score = fusion_fun(align_scores, fusion_type='harmonic_mean')[:, 0].detach()
    if isinstance(global_logits, list):
        global_pq_score = [x.softmax(-1).unsqueeze(-1) for x in global_logits]
        global_pq_score = torch.concat(global_pq_score, dim=-1).mean(dim=-1)[:, 1].detach()
    else:
        global_pq_score = global_logits.softmax(-1)[:, 1].detach()
    return global_pq_score, local_pq_map, align_score


def build_pseudo_prompt(query_feats, query_patch_feats, initial_map, keep_ratio=0.3):
    pseudo_patch_feats = []
    keep_ratio = min(max(float(keep_ratio), 1e-3), 1.0)
    for query_patch_feat in query_patch_feats:
        batch_size, token_num, dim = query_patch_feat.shape
        patch_tokens = query_patch_feat[:, 1:, :]
        patch_num = patch_tokens.shape[1]
        side = int(patch_num ** 0.5)
        patch_scores = F.interpolate(initial_map[:, None], size=(side, side), mode='bilinear', align_corners=False)
        patch_scores = patch_scores.flatten(1)
        keep_num = max(1, int(patch_num * keep_ratio))
        keep_idx = torch.topk(patch_scores, k=keep_num, dim=1, largest=False).indices
        selected = torch.gather(patch_tokens, dim=1, index=keep_idx.unsqueeze(-1).expand(-1, -1, dim))
        prototype = selected.mean(dim=1)
        prototype = F.normalize(prototype, dim=-1)
        repeated_proto = prototype.unsqueeze(1).expand(-1, patch_num, -1)
        pseudo_patch_feat = torch.cat([query_patch_feat[:, :1, :], repeated_proto], dim=1).unsqueeze(1)
        pseudo_patch_feats.append(pseudo_patch_feat)
    pseudo_feats = query_feats.unsqueeze(1)
    return pseudo_feats, pseudo_patch_feats


def build_prompt_memory(model, prompt_dataloader, device, obj_list, view_list, features_list, DPAM_layer):
    feats_scale_num = len(features_list)
    image_temp, patch_temp = [], [[] for _ in range(feats_scale_num)]
    cls_names_temp, view_ids_temp = [], []

    for items in tqdm(prompt_dataloader):
        cls_name = items['cls_name']
        prompt_image = items['img'].to(device)
        view_id = items['view_id']
        with torch.no_grad():
            image_feat, patch_feat = model.encode_image(prompt_image, features_list, DPAM_layer=DPAM_layer)
        cls_names_temp.extend(cls_name)
        image_temp.append(image_feat)
        view_ids_temp.extend(view_id)
        for i in range(feats_scale_num):
            patch_temp[i].append(patch_feat[i])

    image_temp = torch.cat(image_temp, dim=0)
    for i in range(feats_scale_num):
        patch_temp[i] = torch.cat(patch_temp[i], dim=0)

    prompt_image_memory, prompt_patch_memory = {}, {}
    for obj in obj_list:
        if len(view_list) > 1:
            for view_id in view_list:
                indice = (np.array(cls_names_temp) == obj) & (np.array(view_ids_temp) == view_id)
                obj_name = obj + '_' + view_id
                prompt_image_memory[obj_name] = image_temp[indice]
                prompt_patch_memory[obj_name] = [patch_temp[i][indice] for i in range(feats_scale_num)]
        else:
            indice = (np.array(cls_names_temp) == obj)
            obj_name = obj
            prompt_image_memory[obj_name] = image_temp[indice]
            prompt_patch_memory[obj_name] = [patch_temp[i][indice] for i in range(feats_scale_num)]
    return prompt_image_memory, prompt_patch_memory


def prompt_association(image_memory, patch_memory, target_class_name):
    patch_level_num = len(patch_memory[target_class_name[0]])
    retrive_image = []
    retrive_patch = [[] for _ in range(patch_level_num)]
    for class_name in target_class_name:
        retrive_image.append(image_memory[class_name])
        for l in range(patch_level_num):
            retrive_patch[l].append(patch_memory[class_name][l])
    retrive_image = torch.stack(retrive_image)
    for l in range(patch_level_num):
        retrive_patch[l] = torch.stack(retrive_patch[l])
    return retrive_image, retrive_patch


def uncertainty_weighted_pixel_fusion(tensor_list, eps=1e-6):
    if len(tensor_list) == 1:
        return tensor_list[0]
    stacked = torch.stack(tensor_list, dim=0)
    entropy_conf = 1.0 - binary_entropy(stacked)
    mean_map = stacked.mean(dim=0, keepdim=True)
    disagreement_conf = 1.0 - (stacked - mean_map).abs().clamp(0.0, 1.0)
    confidence = (entropy_conf * disagreement_conf).clamp_min(0.0) + eps
    return (stacked * confidence).sum(dim=0) / confidence.sum(dim=0)


def confidence_gated_map_fusion(reference, candidate, confidence=None, max_weight=0.35, min_confidence=0.05):
    if confidence is None:
        confidence = torch.ones(reference.shape[0], device=reference.device)
    denom = max(1.0 - float(min_confidence), 1e-6)
    gate = ((confidence - float(min_confidence)) / denom).clamp(0.0, 1.0)
    gate = gate * float(max_weight)
    return reference * (1.0 - gate[:, None, None]) + candidate * gate[:, None, None], gate


def confidence_gated_score_fusion(reference, candidate, confidence=None, max_weight=0.35, min_confidence=0.05):
    if confidence is None:
        confidence = torch.ones(reference.shape[0], device=reference.device)
    denom = max(1.0 - float(min_confidence), 1e-6)
    gate = ((confidence - float(min_confidence)) / denom).clamp(0.0, 1.0)
    gate = gate * float(max_weight)
    return reference * (1.0 - gate) + candidate * gate


def map_confidence(anomaly_map):
    return (1.0 - binary_entropy(anomaly_map).flatten(1).mean(dim=1)).clamp(0.0, 1.0)


def score_confidence(anomaly_score):
    return (1.0 - binary_entropy(anomaly_score)).clamp(0.0, 1.0)


def disagreement_confidence(reference, candidate):
    return (1.0 - (reference - candidate).abs().flatten(1).mean(dim=1)).clamp(0.0, 1.0)


def save_prompt_weight_records(save_path, filename, records):
    os.makedirs(save_path, exist_ok=True)
    weight_path = os.path.join(save_path, filename)
    with open(weight_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['sample_id', 'cls_name', 'query_path', 'weights', 'scores', 'mcv_scores'])
        writer.writeheader()
        writer.writerows(records)


def test(args):
    img_size = args.image_size
    features_list = args.features_list
    dataset_dir = args.test_data_path
    save_path = args.save_path
    dataset_name = args.dataset
    batch_size = args.batch_size
    k_shots = args.k_shots
    seed = args.seed
    use_sra = args.use_sra
    use_mcv = args.use_mcv
    use_taf = args.use_taf
    use_meta_reliability = args.use_meta_reliability
    structure_align = args.structure_align or ('local_soft_topk' if args.radaptclip and k_shots > 0 else 'soft_topk' if args.radaptclip else 'original')

    mode = 'test'
    log_file = f'{dataset_name}_{seed}seed_{k_shots}shot_{mode}_log.txt'
    logger = get_logger(save_path, log_file)

    innovations = []
    if use_sra: innovations.append('SRA')
    if use_mcv: innovations.append('MCV')
    if use_taf: innovations.append('TAF')
    if use_meta_reliability: innovations.append('MetaReliability')
    logger.info(f'R-AdaptCLIP v2.0 Innovations: {innovations if innovations else ["Baseline"]}')
    logger.info(f'structure_align={structure_align}, align_topk={args.align_topk}')

    device = "cuda" if torch.cuda.is_available() else "cpu"

    model, _ = adaptcliplib.load(args.pretrained_model, device=device)
    model.visual.DAPM_replace(DPAM_layer=20)
    patch_size = 14
    input_dim = 768
    DPAM_layer = 20

    preprocess, target_transform = get_transform(image_size=args.image_size)
    prompt_data = PromptDataset(root=dataset_dir, transform=preprocess, target_transform=target_transform,
                                dataset_name=dataset_name, k_shots=k_shots, save_dir=save_path, mode=mode,
                                seed=seed, class_name=args.class_name)
    test_data = Dataset(root=dataset_dir, transform=preprocess, target_transform=target_transform,
                        dataset_name=dataset_name, k_shots=k_shots, save_dir=save_path, mode=mode,
                        seed=seed, class_name=args.class_name)

    prompt_dataloader = torch.utils.data.DataLoader(prompt_data, batch_size=batch_size, shuffle=False)
    test_dataloader = torch.utils.data.DataLoader(test_data, batch_size=batch_size, shuffle=False, num_workers=4)
    obj_list = test_data.obj_list
    view_list = test_data.view_list

    # Init adapters
    textual_learner = TextualAdapter(model.to("cpu"), img_size, args.n_ctx)
    visual_learner = VisualAdapter(img_size, patch_size, input_dim=input_dim, reduction=args.vl_reduction)
    pq_learner = PQAdapter(img_size, patch_size, context=args.pq_context, input_dim=input_dim,
                           mid_dim=args.pq_mid_dim, layers_num=len(features_list))

    # Init SRA module
    sra_module = SpectralResidualAnalyzer(input_dim=input_dim, num_bands=3, mid_dim=64) if use_sra else None

    logger.info('loading model from: ' + args.checkpoint_path)
    checkpoint_adapter = torch.load(args.checkpoint_path)
    textual_learner.load_state_dict(checkpoint_adapter["textual_learner"])
    visual_learner.load_state_dict(checkpoint_adapter["visual_learner"])
    pq_learner.load_state_dict(checkpoint_adapter["pq_learner"])

    model.to(device)
    textual_learner.to(device)
    visual_learner.to(device)
    pq_learner.to(device)
    if sra_module:
        sra_module.to(device)

    model.eval()
    textual_learner.eval()
    visual_learner.eval()
    pq_learner.eval()
    if sra_module:
        sra_module.eval()

    params_info = {
        'textual': sum(p.numel() for p in textual_learner.parameters()),
        'visual': sum(p.numel() for p in visual_learner.parameters()),
        'pq': sum(p.numel() for p in pq_learner.parameters()),
        'sra': sum(p.numel() for p in sra_module.parameters()) if sra_module else 0,
        'fixed': sum(p.numel() for p in model.parameters()),
    }
    logger.info(f"Params: textual={params_info['textual']}, visual={params_info['visual']/1e6:.1f}M, "
                f"pq={params_info['pq']/1e6:.1f}M, sra={params_info['sra']}, "
                f"total_learned={(params_info['textual']+params_info['visual']+params_info['pq']+params_info['sra'])/1e6:.1f}M")

    evaluator = Evaluator(device, metrics=args.eval_metrics)

    # Textual adapter prepare
    textual_learner.prepare_static_text_feature(model)
    static_text_features = textual_learner.static_text_features
    learned_prompts, tokenized_prompts = textual_learner()
    learned_text_features = model.encode_text_learn(learned_prompts, tokenized_prompts).float()

    # Build prompt memory for few-shot
    if k_shots > 0:
        prompt_image_memory, prompt_patch_memory = build_prompt_memory(
            model, prompt_dataloader, device, obj_list, view_list, args.features_list, DPAM_layer)

    # Inference loop
    sample_ids, gt_masks, pr_masks, cls_names, gt_anomalys, pr_anomalys, query_paths = [], [], [], [], [], [], []
    prompt_weight_records = []

    for items in tqdm(test_dataloader):
        query_image = items['img'].to(device)
        current_batchsize = query_image.shape[0]
        query_path = items['img_path']
        cls_name = items['cls_name']
        sample_id = items['sample_id']
        gt_anomaly = items['anomaly'].to(device)
        gt_mask = items['img_mask'][:, 0]
        gt_mask[gt_mask > 0.5], gt_mask[gt_mask <= 0.5] = 1, 0
        gt_mask = gt_mask.to(device)

        with torch.no_grad():
            query_feats, query_patch_feats = model.encode_image(query_image, args.features_list, DPAM_layer=DPAM_layer)

        if k_shots > 0:
            if len(view_list) > 1:
                target_cls_name = [cls_name + '_' + view_id for cls_name, view_id in zip(cls_name, items['view_id'])]
            else:
                target_cls_name = cls_name
            prompt_feats, prompt_patch_feats = prompt_association(prompt_image_memory, prompt_patch_memory, target_cls_name)

        # Visual adapter
        global_vl_logit, local_vl_map = visual_learner(query_feats, query_patch_feats, static_text_features)
        local_vl_map = local_vl_map[:, 1].detach()
        global_vl_score = global_vl_logit.softmax(-1)[:, 1].detach()

        # Textual adapter
        global_tl_logit, local_tl_map = textual_learner.compute_global_local_score(query_feats, query_patch_feats, learned_text_features)
        local_tl_map = local_tl_map[:, 1].detach()
        global_tl_score = global_tl_logit.softmax(-1)[:, 1].detach()

        # PQ adapter
        baseline_global_pq_score, baseline_local_pq_map = None, None
        prompt_weights, mcv_scores_out = None, None

        if args.pq_learner and k_shots > 0:
            if args.radaptclip:
                # Fallback baseline
                baseline_global_pq_logit, baseline_local_pq_list, baseline_align_scores = pq_learner(
                    query_feats, query_patch_feats, prompt_feats, prompt_patch_feats)
                baseline_global_pq_score, baseline_local_pq_map, baseline_align_score = collapse_standard_pq_outputs(
                    baseline_global_pq_logit, baseline_local_pq_list, baseline_align_scores)

                # Promptwise forward
                global_pq_logit, local_pq_map_list, align_scores_list, align_distances = pq_learner.forward_promptwise(
                    query_feats, query_patch_feats, prompt_feats, prompt_patch_feats,
                    structure_align=structure_align, align_topk=args.align_topk,
                    align_temperature=args.align_temperature, align_window=args.align_window,
                    align_spatial_weight=args.align_spatial_weight)
                prompt_global_scores, prompt_local_maps, prompt_align_maps, prompt_align_distances = collapse_promptwise_outputs(
                    global_pq_logit, local_pq_map_list, align_scores_list, align_distances)

                # Compute reliability
                if use_meta_reliability:
                    prompt_weights, prompt_scores, mcv_scores_out, _ = compute_meta_reliability(
                        query_feats, prompt_feats, prompt_local_maps, prompt_align_distances,
                        global_pq_logit, local_pq_map_list, align_scores_list,
                        align_temperature=args.align_temperature,
                        reliability_temperature=args.reliability_temperature)
                elif use_mcv:
                    mcv_scores_out, _ = mutual_consistency_scores(
                        global_pq_logit, local_pq_map_list, align_scores_list)
                    # Combine with HRD
                    prompt_weights, prompt_scores = compute_prompt_reliability(
                        query_feats, prompt_feats, prompt_local_maps, prompt_align_distances,
                        align_temperature=args.align_temperature,
                        reliability_temperature=args.reliability_temperature)
                    # Blend: 70% HRD, 30% MCV
                    blended = 0.7 * prompt_scores + 0.3 * mcv_scores_out
                    prompt_weights = normalize_prompt_scores(blended, temperature=args.reliability_temperature)
                else:
                    prompt_weights, prompt_scores = compute_prompt_reliability(
                        query_feats, prompt_feats, prompt_local_maps, prompt_align_distances,
                        align_temperature=args.align_temperature,
                        reliability_temperature=args.reliability_temperature)

                prompt_weights = prompt_weights.detach()
                prompt_scores = prompt_scores.detach()

                # Apply TAF or standard fusion
                if use_taf:
                    local_pq_map, _ = temperature_annealed_fusion(
                        prompt_local_maps, None, prompt_weights,
                        base_temperature=args.reliability_temperature,
                        min_temperature=0.1, max_temperature=5.0)
                    global_pq_score, _ = temperature_annealed_fusion(
                        prompt_global_scores, None, prompt_weights,
                        base_temperature=args.reliability_temperature,
                        min_temperature=0.1, max_temperature=5.0)
                else:
                    local_pq_map = (prompt_local_maps * prompt_weights[:, :, None, None]).sum(dim=1).detach()
                    global_pq_score = (prompt_global_scores * prompt_weights).sum(dim=1).detach()

                align_score = (prompt_align_maps * prompt_weights[:, :, None, None]).sum(dim=1).detach()

                # Save prompt weights
                if args.save_prompt_weights:
                    weights_cpu = prompt_weights.cpu().numpy()
                    scores_cpu = prompt_scores.cpu().numpy()
                    mcv_cpu = mcv_scores_out.cpu().numpy() if mcv_scores_out is not None else np.zeros_like(scores_cpu)
                    for sample_idx in range(current_batchsize):
                        prompt_weight_records.append({
                            'sample_id': str(sample_id[sample_idx]),
                            'cls_name': str(cls_name[sample_idx]),
                            'query_path': str(query_path[sample_idx]),
                            'weights': ';'.join([f'{x:.6f}' for x in weights_cpu[sample_idx]]),
                            'scores': ';'.join([f'{x:.6f}' for x in scores_cpu[sample_idx]]),
                            'mcv_scores': ';'.join([f'{x:.6f}' for x in mcv_cpu[sample_idx]]),
                        })
            else:
                global_pq_logit, local_pq_list, align_scores_list = pq_learner(
                    query_feats, query_patch_feats, prompt_feats, prompt_patch_feats)
                global_pq_score, local_pq_map, align_score = collapse_standard_pq_outputs(
                    global_pq_logit, local_pq_list, align_scores_list)

        # Zero-shot pseudo prompt
        local_pseudo_map, global_pseudo_score = None, None
        if args.radaptclip and args.pq_learner and k_shots == 0:
            initial_zero_map = fusion_fun([local_vl_map, local_tl_map], fusion_type=args.fusion_type).detach()
            pseudo_feats, pseudo_patch_feats = build_pseudo_prompt(
                query_feats, query_patch_feats, initial_zero_map, keep_ratio=args.pseudo_keep_ratio)
            global_pseudo_logit, local_pseudo_list, align_pseudo_scores, align_pseudo_dist = pq_learner.forward_promptwise(
                query_feats, query_patch_feats, pseudo_feats, pseudo_patch_feats,
                structure_align='soft_topk', align_topk=args.align_topk,
                align_temperature=args.align_temperature, align_window=args.align_window)
            prompt_gs, prompt_lm, _, _ = collapse_promptwise_outputs(
                global_pseudo_logit, local_pseudo_list, align_pseudo_scores, align_pseudo_dist)
            local_pseudo_map = prompt_lm[:, 0].detach()
            global_pseudo_score = prompt_gs[:, 0].detach()

        # === Fusion ===
        if k_shots > 0:
            base_pixel_map = fusion_fun([local_vl_map, local_tl_map, baseline_local_pq_map], fusion_type=args.fusion_type)
            base_pixel_map = fusion_fun([base_pixel_map, baseline_align_score], fusion_type='harmonic_mean')
            base_image_pred = fusion_fun([global_vl_score, global_tl_score, baseline_global_pq_score], fusion_type=args.fusion_type)

            radapt_pixel_map = uncertainty_weighted_pixel_fusion([local_vl_map, local_tl_map, local_pq_map])
            radapt_pixel_map = fusion_fun([radapt_pixel_map, align_score], fusion_type='harmonic_mean')
            anomaly_map_max, _ = torch.max(base_pixel_map.view(current_batchsize, -1), dim=1)
            base_image_pred = fusion_fun([base_image_pred, anomaly_map_max], fusion_type="harmonic_mean")

            radapt_image_pred = uncertainty_weighted_pixel_fusion([global_vl_score, global_tl_score, global_pq_score])
            radapt_image_pred = fusion_fun([radapt_image_pred, anomaly_map_max], fusion_type="harmonic_mean")

            pixel_conf = map_confidence(radapt_pixel_map) * disagreement_confidence(base_pixel_map, radapt_pixel_map)
            pixel_anomaly_map, _ = confidence_gated_map_fusion(
                base_pixel_map, radapt_pixel_map, confidence=pixel_conf,
                max_weight=args.pixel_gate_max_weight, min_confidence=args.pixel_gate_min_confidence)

            image_conf = score_confidence(radapt_image_pred)
            image_anomaly_pred = confidence_gated_score_fusion(
                base_image_pred, radapt_image_pred, confidence=image_conf,
                max_weight=args.image_gate_max_weight, min_confidence=args.image_gate_min_confidence)
        else:
            base_pixel_map = fusion_fun([local_vl_map, local_tl_map], fusion_type=args.fusion_type)
            zero_maps = [local_vl_map, local_tl_map]
            if local_pseudo_map is not None:
                zero_maps.append(local_pseudo_map)
            radapt_pixel_map = uncertainty_weighted_pixel_fusion(zero_maps)
            pixel_conf = map_confidence(radapt_pixel_map) * disagreement_confidence(base_pixel_map, radapt_pixel_map)
            pixel_anomaly_map, _ = confidence_gated_map_fusion(
                base_pixel_map, radapt_pixel_map, confidence=pixel_conf,
                max_weight=args.pixel_gate_max_weight, min_confidence=args.pixel_gate_min_confidence)

            pixel_anomaly_map_smooth = torch.stack(
                [torch.from_numpy(gaussian_filter(i, sigma=args.sigma)) for i in pixel_anomaly_map.cpu()], dim=0).to(device)
            anomaly_map_max, _ = torch.max(pixel_anomaly_map_smooth.view(current_batchsize, -1), dim=1)
            zero_scores = [global_vl_score, global_tl_score, anomaly_map_max]
            if global_pseudo_score is not None:
                zero_scores.append(global_pseudo_score)
            image_anomaly_pred = uncertainty_weighted_pixel_fusion(zero_scores)

        pixel_anomaly_map = torch.stack(
            [torch.from_numpy(gaussian_filter(i, sigma=args.sigma)) for i in pixel_anomaly_map.cpu()], dim=0).to(device)
        pixel_anomaly_map = torch.nan_to_num(pixel_anomaly_map, nan=0.0, posinf=0.0, neginf=0.0)
        image_anomaly_pred = torch.nan_to_num(image_anomaly_pred, nan=0.0, posinf=0.0, neginf=0.0)

        sample_ids.append(np.array(sample_id))
        cls_names.append(np.array(cls_name))
        query_paths.append(np.array(query_path))
        gt_masks.append(gt_mask.int())
        pr_masks.append(pixel_anomaly_map)
        gt_anomalys.append(gt_anomaly.int())
        pr_anomalys.append(image_anomaly_pred)

    # Evaluation
    results_eval = dict(sample_ids=sample_ids, gt_masks=gt_masks, pr_masks=pr_masks,
                        cls_names=cls_names, gt_anomalys=gt_anomalys, pr_anomalys=pr_anomalys,
                        query_paths=query_paths)
    results_eval = {k: np.concatenate(v, axis=0) if k in ['cls_names', 'query_paths', 'sample_ids']
                    else torch.cat(v, dim=0) for k, v in results_eval.items()}

    msg = {}
    for idx, cls_name in enumerate(tqdm(obj_list)):
        metric_results = evaluator.run(results_eval, cls_name, logger)
        msg['Name'] = msg.get('Name', [])
        msg['Name'].append(cls_name)
        avg_act = True if len(obj_list) > 1 and idx == len(obj_list) - 1 else False
        msg['Name'].append('Avg') if avg_act else None
        for metric in args.eval_metrics:
            metric_result = metric_results[metric] * 100
            msg[metric] = msg.get(metric, [])
            msg[metric].append(metric_result)
            if avg_act:
                msg[metric].append(sum(msg[metric]) / len(msg[metric]))

    tab = tabulate(msg, headers='keys', tablefmt="pipe", floatfmt='.1f', numalign="center", stralign="center")
    logger.info('\n' + tab)

    if args.save_prompt_weights and prompt_weight_records:
        weight_file = f'{dataset_name}_{seed}seed_{k_shots}shot_prompt_weights.csv'
        save_prompt_weight_records(save_path, weight_file, prompt_weight_records)

    return msg


if __name__ == '__main__':
    parser = argparse.ArgumentParser("R-AdaptCLIP-v2")
    parser.add_argument("--test_data_path", type=str, default="./data/visa")
    parser.add_argument("--save_path", type=str, default='./results/')
    parser.add_argument("--pretrained_model", type=str, default='ViT-L/14@336px')
    parser.add_argument("--checkpoint_path", type=str, default='./adaptclip_checkpoints/12_4_128_train_on_visa_3adapters_batch8/epoch_15.pth')
    parser.add_argument("--dataset", type=str, default='mvtec')
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24])
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--image_size", type=int, default=518)
    parser.add_argument("--n_ctx", type=int, default=12)
    parser.add_argument("--seed", type=int, default=10)
    parser.add_argument("--sigma", type=int, default=4)
    parser.add_argument("--k_shots", type=int, default=0)
    parser.add_argument("--visual_learner", action="store_true")
    parser.add_argument("--textual_learner", action="store_true")
    parser.add_argument("--pq_learner", action="store_true")
    parser.add_argument("--eval_metrics", type=str, nargs="+",
                        default=['I-AUROC', 'I-AP', 'I-F1max', 'P-AUROC', 'P-AP', 'P-F1max', 'P-AUPRO'])
    parser.add_argument("--fusion_type", type=str, default="average_mean")
    parser.add_argument("--vl_reduction", type=int, default=4)
    parser.add_argument("--pq_mid_dim", type=int, default=128)
    parser.add_argument("--pq_context", action="store_true")
    parser.add_argument("--radaptclip", action="store_true")
    parser.add_argument("--structure_align", type=str, default=None)
    parser.add_argument("--align_topk", type=int, default=5)
    parser.add_argument("--align_temperature", type=float, default=0.05)
    parser.add_argument("--align_window", type=int, default=2)
    parser.add_argument("--align_spatial_weight", type=float, default=0.0)
    parser.add_argument("--reliability_temperature", type=float, default=1.0)
    parser.add_argument("--pseudo_keep_ratio", type=float, default=0.3)
    parser.add_argument("--pixel_gate_max_weight", type=float, default=0.1)
    parser.add_argument("--pixel_gate_min_confidence", type=float, default=0.05)
    parser.add_argument("--image_gate_max_weight", type=float, default=0.35)
    parser.add_argument("--image_gate_min_confidence", type=float, default=0.05)
    # NEW: Innovation flags
    parser.add_argument("--use_sra", action="store_true", help="Enable Spectral Residual Analysis")
    parser.add_argument("--use_mcv", action="store_true", help="Enable Mutual Consistency Verification")
    parser.add_argument("--use_taf", action="store_true", help="Enable Temperature-Annealed Fusion")
    parser.add_argument("--use_meta_reliability", action="store_true", help="Enable Meta-Reliability (HRD+MCV)")
    parser.add_argument("--save_prompt_weights", action="store_true")
    parser.add_argument("--save_visuals", action="store_true")
    parser.add_argument("--class_name", type=str, help="class name")
    args = parser.parse_args()
    setup_seed(args.seed)
    test(args)
