# Repository Instructions

- Do not batch delete files or directories.
- Use the interpreter `D:/work/anaconda/envs/py39_pytorch2.3.1/python.exe` when reproducing the local experiments.
- The target hardware is an RTX 3070 GPU with 8 GB VRAM; prefer single-class, small-batch, short-timeout runs before any full-dataset run.
- Put new datasets and experiment outputs on the E drive.
- Do not fabricate experiment results. Only update paper conclusions from traceable logs.
- Paper figures and tables should be appended or carefully refined, not casually removed.

## Paper Story

The manuscript should emphasize a practical small-enterprise quality-assurance problem. A customized visual inspection system is expensive for small manufacturers because it often requires product-specific hardware integration, dataset collection, defect annotation, model training, and long-term maintenance. As a result, many workshops still depend on manual inspection even when manual inspection is slow and unstable.

R-AdaptCLIP is positioned as a low-cost, zero-shot or few-shot inspection framework that can run on a consumer-level RTX 3070 GPU. The system is intended as a plug-and-play inspection entry point: companies can try zero-shot detection without building a large labeled dataset, and they can optionally add a few normal product images for Top-k Reliability Prompt Selection.

For IJSAEM, prioritize system assurance, deployability, risk control, and engineering management value over exaggerated SOTA claims.
*** Add File: E:\CILP\RAdaptCLIP_release_clean\.gitignore
# Python
__pycache__/
*.py[cod]
*.pyo
.pytest_cache/

# IDE
.idea/
.vscode/

# Large datasets and checkpoints
data/
hf_mvtec_ad/
adaptclip_checkpoints/
checkpoints/
adaclip_checkpoints/
dataset/mvtec/
dataset/visa/
dataset/kvasir_seg_small/
dataset/xiguan_yolo/

# Full experiment outputs
results/
outputs/
runs/

# Model weights
*.pth
*.pt
*.ckpt
*.safetensors

# LaTeX and local temporary files
*.aux
*.bbl
*.blg
*.log
*.out
*.synctex.gz
*.tmp
*** Add File: E:\CILP\RAdaptCLIP_release_clean\sample_data\straw_defect_deidentified\README.md
# De-identified Straw Defect Samples

This folder contains three de-identified straw defect samples used only for qualitative visualization in the IJSAEM manuscript.

- `images/test/`: input straw images.
- `masks/test/`: corresponding binary defect masks.

The complete internal straw defect dataset is not included because it contains production images. These examples are intended to show the data format and the qualitative inspection case, not to support full quantitative claims.
*** Add File: E:\CILP\RAdaptCLIP_release_clean\paper_artifacts\logs\README.md
# Trace Logs

This folder contains selected trace logs used by the IJSAEM manuscript.

The straw risk-fusion table is based on:

- `rtx3070_xiguan_risk_fast_summary.json`
- `rtx3070_xiguan_risk_fast/baseline_sigma4/`
- `rtx3070_xiguan_risk_fast/fixed_gate0p2_sigma4/`
- `rtx3070_xiguan_risk_fast/risk_gate_balanced_sigma4/`
- `rtx3070_xiguan_risk_fast/risk_gate_recall_sigma4/`

The visualization-only capped runs are based on:

- `straw_case_visuals_baseline_20260611/`
- `straw_case_visuals_fixed035_20260611/`
- `straw_case_visuals_riskbalanced_20260611/`

Visualization-only runs use `--max_test_samples 3` and should not be interpreted as full quantitative evidence.
